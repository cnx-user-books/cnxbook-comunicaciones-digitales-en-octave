#programa 8 modulaciones binarias y marias

clear all
close all 
disp("               Programa 8: Modulaciones Binarias  y M-arias         \n "); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("% Usted puede seleccionar que modulaci�n desea(OOK,PSK,FSK,QPSK)                     %"); 
disp("% EL sistema est� formado por el transmisor, un canal AWGN y un receptor s�ncrono    %"); 
disp("% Se presenta la gr�fica de Pe vs E/n te�rica y pr�ctica                             %"); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	

pause(3)
  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%           Modulaci�n Binaria y M-aria     %"); 
disp("% Seleccione el tipo de modulaci�n :        %");
disp("% (1)OOK                                    %");
disp("% (2)PSK                                    %");
disp("% (3)FSK                                    %");
disp("% (4)QPSK                                   %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	
input(" ");
o=input("ingrese la opci�n: ");%el usuario el tipo de modulaci�n 
pause(2)
disp("\n "); 
%---------------Parte Inicial---------------------
%generaci�n de bits
L=4000;% el usuario introduce el n�mero de bits que desea generar
b=randint(1,L,2);  %Datos binarios aleatorios
%-------------------------------------------------
if o==1
	ook(b,L); 
endif 

 
if o==2 
	psk(b,L);
endif 
 
if o==3
	fsk(b,L);
endif 
 
if o==4
	qpsk(b,L);
endif


