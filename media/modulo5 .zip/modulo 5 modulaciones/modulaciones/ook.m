function [] = ook(x,l)
 



b=x;% secuencia de bit generada en el programa principal
L=l;% n�mero de bits generados

%-------------------------------------------------
%%%%%%%% OOK %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%Cambia la Amplitud%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%-------------------------------------------------

fs=1000;%frecuencia de muestreo
tb=0:0.001:0.1-0.001; %tiempo para las bases  
fb=10;%frecuencia de bit 
%el tiempo de bit es 1 segundo

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%           Modulaci�n OOK                  %"); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	

disp("%-------------------------------------------------------------%");
disp("%  La frecuencia de muestreo para OOK se fija en 1000 Hz      %"); 
disp("%  El tiempo de bit se fija en 100ms                          %"); 
disp("%  Usted debe seleccionar la frecuencia de portadora,         %");
disp("%  Usted debe seleccionar la potencia de ruido del canal.     %");
disp("%-------------------------------------------------------------%");
disp("% Introduzca la frecuencia de portadora (fp)                           %");
disp("% La frecuencia debe estar comprendida entre valores de:  10Hz a 500Hz %");
disp("% Se recomienda colocar como frecuencia de muestreo 100Hz              %");
pause(7)
fp=input("Ingrese la fp en Hz: ");%el usuario introduce la fp
pause(2)
disp("\n "); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%OOK%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% se le asigna a cada bit 100 puntos para graficar la secuencia de bits 
nm=100;%n�mero de muestras por bit
unos=ones(1,nm);
ceros=zeros(1,nm);

bo=[];
for i=1:length(b)
        switch b(i)
            case 0
                bo=[bo  ceros];
            case 1
                bo=[bo  unos];
           
        end
                
end




uOOK=sqrt(2*fb)*cos(2*pi*fp*tb);%base u1 OOK representada con 100 puntos
long1=length(tb);
yook=[];%vector vacio senal OOK 
for i=1:L
        switch b(i)
            case 0
                yook(1+long1*(i-1):long1*i)=[0*uOOK];
            case 1
                yook(1+long1*(i-1):long1*i)=[uOOK];
        end
                
end
%yook se�al OOK generada.

s=length(yook)*fb;%longitud de la secuecnia de bits
t=[0:1/fs:((L*100)-1)/fs];%vector tiempo


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% DEP OOK %%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

l=length(yook);
f=linspace(-fs/2,fs/2,l);%vector de frecuencia
depook=fftshift((abs(fft(yook))).^2)/(l);

figure(1)
subplot(2,1,1)
plot(t,bo);
axis ([0 10 -2 2])
legend (' Secuencia de bits'); 
xlabel('t(s)');
subplot(2,1,2)
plot(t,yook);
axis ([0 10])
legend (' Senal OOK en tiempo'); 
xlabel('t(s)');


figure(2)
subplot(2,1,1)
plot(t,yook);
axis ([0 2])
legend (' Senal OOK en tiempo'); 
xlabel('t(s)');
subplot(2,1,2)
plot(f,depook);
legend (' DEP de Senal OOK');
xlabel('f(Hz)'); 

fs1=100;
dett1=[]; 
dett21=[];

u2=ceros;%base de cero  (100 ceros)


for k=1:L
          dett1(k)=(1/fb)*mean(yook(1+(k-1)*fs1:k*fs1).*uOOK);    
end  

figure(3) 
scatter(dett1,dett1*0,'filled');
axis([-2 2 -2 2]);
title('Constelacion OOK')

%-------------------------------------------------
%********************CANAL************************
%-------------------------------------------------

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%        RUIDO DEL CANAL                    %"); 
disp("% Seleccione la potencia de ruido :         %");
disp("% (1)40 W                                   %");
disp("% (2)60 W                                   %");
disp("% (3)80 W                                   %");
disp("% (4)100 W                                  %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	
RUIDO=input("ingrese la opcion: ");%el usuario selcciona la potencia de ruido
pause(2)
disp("\n "); 

if RUIDO==1 
     RUIDO=40;
endif
if RUIDO==2 
        RUIDO=60;
endif
if RUIDO==3    
          RUIDO=80;       
end
if RUIDO==4    
          RUIDO=100;        
end
noiseu=sqrt(RUIDO)*randn(size(yook));
y0=yook+noiseu;% se le suma ruido a la se�al
	figure(4)
	subplot(2,1,1)  
	plot(t,y0);
	axis ([0 10])
	legend (' Senal OOK + RUIDO');
	xlabel('t(s)');
	subplot(2,1,2)
	yfrec = (abs(fft(y0)).^2)/(l);
	plot(0:fs/length(y0):fs/2-fs/length(y0),yfrec(1:length(y0)/2))
	legend ('DEP Unilateral OOK + RUIDO');
	xlabel('f(Hz)');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% DETECTOR OOK %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
fs1=100;
dett=[];
dett2=[];
rec=[];%secuencia de bit recuperada 


 

for k=1:L
          dett(k)=mean(y0(1+(k-1)*fs1:k*fs1).*uOOK);    
end 

      for k=1:L
                if dett(k)>5  
                    rec(k)=1;
						    else
                    rec(k)=0;
                end
end
 




%rec es la secuencia de bit recuperada



br=[];
for i=1:length(rec)
        switch rec(i) 
            case 0
                br=[br  ceros];
            case 1
                br=[br  unos];
           
        end
                
end

	figure(5)
	subplot(2,1,1)  
	plot(t,bo); 
	xlabel('Segundos');
	axis([0 10 -2 2]);
  legend (' Secuencia de bits original');
	subplot(2,1,2)
	plot(t,br); 
	xlabel('Segundos');
	axis([0 10 -2 2]);
  legend (' Secuencia de bits recuperada');
	err= size(find([rec - b]),2)/length(b)

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# %%%%%%%% Para la probabilidad de error %%%%%%%%%%%
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# 
noise0=sqrt(0.45*RUIDO)*randn(size(yook));
noise1=sqrt(0.60*RUIDO)*randn(size(yook));
noise2=sqrt(0.75*RUIDO)*randn(size(yook));
noise3=sqrt(0.90*RUIDO)*randn(size(yook));
noise4=noiseu;
noise5=sqrt(2.00*RUIDO)*randn(size(yook));
noise6=sqrt(3.00*RUIDO)*randn(size(yook));
noise7=sqrt(4.00*RUIDO)*randn(size(yook));
noise8=sqrt(5.00*RUIDO)*randn(size(yook)); 
%se�ales mas ruido

y4=y0;%potencia introducida manualmente por el usuario
y0=yook+noise0;
y1=yook+noise1;
y2=yook+noise2;
y3=yook+noise3;
y5=yook+noise5;
y6=yook+noise6;
y7=yook+noise7;
y8=yook+noise8;


# %% Detecci�n de las otras se�ales con ruido %%%%%%
# %%%%%%%necesario para la gr�fica de Pe vs. E/n%%%%%%
 
det0=[];
det1=[];
det2=[];
det3=[];
det4=[];
det5=[];
det6=[];
det7=[];
det8=[];


 fs1=100;
  for k=1:L
           det0(k)=mean(y0(1+(k-1)*fs1:k*fs1).*uOOK); 
  if det0(k)>5  
                    det0(k)=1;
						    else
                    det0(k)=0;
  end      

 
           det1(k)=mean(y1(1+(k-1)*fs1:k*fs1).*uOOK); 
  if det1(k)>5  
                    det1(k)=1;
						    else
                    det1(k)=0;
  end           
  

 
           det2(k)=mean(y2(1+(k-1)*fs1:k*fs1).*uOOK); 
  if det2(k)>5  
                    det2(k)=1;
						    else
                    det2(k)=0;
  end           


           det3(k)=mean(y3(1+(k-1)*fs1:k*fs1).*uOOK); 
  if det3(k)>5  
                    det3(k)=1;
						    else
                    det3(k)=0;
  end           


           det4(k)=mean(y4(1+(k-1)*fs1:k*fs1).*uOOK); 
  if det4(k)>5  
                    det4(k)=1;
						    else
                    det4(k)=0;
  end           


           det5(k)=mean(y5(1+(k-1)*fs1:k*fs1).*uOOK);  
		if det5(k)>5  
                    det5(k)=1;
						    else
                    det5(k)=0;
  end     
 

           det6(k)=mean(y6(1+(k-1)*fs1:k*fs1).*uOOK);
		if det6(k)>5  
                    det6(k)=1;
						    else
                    det6(k)=0;
  end     


           det7(k)=mean(y7(1+(k-1)*fs1:k*fs1).*uOOK); 
  if det7(k)>5  
                    det7(k)=1;
						    else
                    det7(k)=0;
  end           


           det8(k)=mean(y8(1+(k-1)*fs1:k*fs1).*uOOK); 
  if det8(k)>5  
                    det8(k)=1;
						    else
                    det8(k)=0;
  end           
end 
 

# %%%%%%% Pe vs. E/n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  errores0= size(find([b - det0]),2)/length(det0);
  errores1= size(find([b - det1]),2)/length(det1);
  errores2= size(find([b - det2]),2)/length(det2);
  errores3= size(find([b - det3]),2)/length(det3);
  errores4= size(find([b - det4]),2)/length(det4);
  errores5= size(find([b - det5]),2)/length(det5);
  errores6= size(find([b - det6]),2)/length(det6);
  errores7= size(find([b - det7]),2)/length(det7);
  errores8= size(find([b - det8]),2)/length(det8);

 eta0=mean(noise0.^2); 
 eta1=mean(noise1.^2);
 eta2=mean(noise2.^2);
 eta3=mean(noise3.^2);
 eta4=mean(noise4.^2);
 eta5=mean(noise5.^2);
 eta6=mean(noise6.^2);
 eta7=mean(noise7.^2);
 eta8=mean(noise8.^2);
 etas=[eta8 eta7 eta6 eta5 eta4 eta3 eta2 eta1 eta0];
P=mean(yook.*yook);
EnerProm=P*0.1; 
 
 EN0=10*log10(EnerProm*0.5*fs/eta0);
 EN1=10*log10(EnerProm*0.5*fs/eta1);
 EN2=10*log10(EnerProm*0.5*fs/eta2);
 EN3=10*log10(EnerProm*0.5*fs/eta3);
 EN4=10*log10(EnerProm*0.5*fs/eta4);
 EN5=10*log10(EnerProm*0.5*fs/eta5); 
 EN6=10*log10(EnerProm*0.5*fs/eta6);
 EN7=10*log10(EnerProm*0.5*fs/eta7);
 EN8=10*log10(EnerProm*0.5*fs/eta8);

EN=[EN8 EN7 EN6 EN5 EN4 EN3 EN2 EN1 EN0];
 BERteorico = qfunc(sqrt(P*fs./(2*fb*etas)));
 BERpractico= [errores8 errores7 errores6 errores5 errores4 errores3 errores2 errores1 errores0];


 figure(6)
 semilogy(EN,BERteorico,'b');
 hold on 
 semilogy(EN,BERpractico,'m.-');
 hold on
 semilogy(EN4,errores4,'g*');
 grid on
 %zoom on
 legend('teorico', 'practico', 'usuario');
 xlabel('E/N, dB')
 ylabel('Tasa de Error por Simbolo')
 %axis([0 20 10^-4 1])
 title('Pe vs E/n modulacion OOK') 