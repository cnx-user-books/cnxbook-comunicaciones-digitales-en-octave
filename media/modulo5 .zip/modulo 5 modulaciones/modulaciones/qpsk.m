 function [] = qpsk(x,l)
  b=x;% secuencia de bit generada en el programa principal
  L=l;%n�mero de bits generados
  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%           Modulaci�n QPSK                 %"); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	

disp("%-------------------------------------------------------------%");
disp("%  La frecuencia de muestreo para qpks se fija en 1000 Hz     %"); 
disp("%  El tiempo de s�mbolo se fija en 200ms                      %"); 
disp("%  Usted debe seleccionar la frecuencia de portadora,         %");
disp("%  Usted debe seleccionar la potencia de ruido del canal.     %");
disp("%-------------------------------------------------------------%");
pause(7)
disp("% Introduzca la frecuencia de portadora (fp)                          %");
disp("% La frecuencia debe estar compredida entre valores de:  10Hz a 500Hz %");
fp=input("Ingrese la fp en Hz: ");%el usuario introduce la fp
pause(2)
disp("\n "); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% QPSK%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%se utilizan los datos binarios b(t) que ya se generaron 
#cada pareja representar� un s�mbolo que generar� una sinusoide con una fase determinada

fs=1000;%frecuencia de muestreo
bpar=[];%guarda los bit pares
bimpar=[];%guarda los bit impares

	for i=1:2:length(b)
		bimpar(i)=b(i);%guarda los impares
		bimpar(i+1)=b(i);
end

	for i=2:2:length(b)
		bpar(i-1)=b(i);%guarda los pares
		bpar(i)=b(i);
    end


ximpar=2*bimpar-1;% se genera una se�al con los bits impares dandole valores de 1 y -1
xpar=2*bpar-1;% se genera una se�al con los bit pares dandole valores de 1 y -1

nm=100;%n�mero de muestras por bit
unos=ones(1,nm);
ceros=zeros(1,nm);

bo=[];%secuencia de bits
for i=1:length(b)
        switch b(i)
            case 0
                bo=[bo  ceros];
            case 1
                bo=[bo  unos];
           
        end
                
end

bi=[];%secuencia par
for i=1:length(xpar)
        switch xpar(i)
            case -1
                bi=[bi  -unos];
            case 1
                bi=[bi  unos];
           
        end
                 
end
 
 
bp=[];%secuencia impar
for i=1:length(ximpar)
        switch ximpar(i)
            case -1
                bp=[bp  -unos];
            case 1
                bp=[bp  unos];
           
        end
                
end




 


%El tiempo de bit es 2 seg
tb2=0:0.001:0.2-0.001; % Vector de tiempo para la base longitud 200
%el tiempo de bit es 0.2
% tb2 es un  vector del doble de largo 
%porque ahora un s�mbolo durar� el doble que un bit.
%Se generan nuevas bases que en 0.2 segundos tengan energ�a unitaria
fb=10;%frecuencia de bit
ts2=0.2;%tiempo de s�mbolo
ucos=sqrt(2/ts2)*cos(2*pi*fp*tb2);% se mantiene la misma frecuencia de portadora que en PSK
usin=sqrt(2/ts2)*sin(2*pi*fp*tb2);  


# Se genera la se�al QPSK en su versi�n de modulaci�n cuaternaria

# Cuando xpar y ximpar tomen valores de 1 y -1 se generan las se�ales siguientes
# Cuando xpar=1 y ximpar =1 la se�al modulada es cos(2*pi*fp*tb2)-sin(2*pi*fp*tb2)
# Cuando xpar= 1 y ximpar =-1 la se�al modulada es -cos(2*pi*fp*tb2)-sin(2*pi*fp*tb2)
# Cuando xpar= -1 y ximpar =1 la se�al modulada es cos(2*pi*fp*tb2)+sin(2*pi*fp*tb2)
# Cuando xpar= -1 y ximpar -1 la se�al modulada es -cos(2*pi*fp*tb2)+sin(2*pi*fp*tb2)

yqpsk=[];%vector donde se almacenar� al se�al QPSK

long2=length(tb2);
for i=1:2:L
    if xpar(i)==1 && ximpar(i)==1
						yqpsk=[yqpsk ucos-usin]; 
            elseif xpar(i)==1 && ximpar(i)==-1
						yqpsk=[yqpsk -ucos-usin];  
    elseif xpar(i)==-1 && ximpar(i)==1
            yqpsk=[yqpsk ucos+usin];
                elseif xpar(i)==-1 && ximpar(i)==-1
            yqpsk=[yqpsk -ucos+usin];
            
    end
end
%normalizaci�n de la se�al yqpsk


y2max=abs(max(yqpsk));
y2min=abs(min(yqpsk));

if y2max>=y2min
    voltnorm=y2max;
elseif y2min>y2max
    voltnorm=y2min;
end

yqpsk=yqpsk/voltnorm;

%en el vector yqpsk se encuentra la se�al QPSK generada  por 4 s�mbolos y 2 bases 
%vector tiempo
t2=[0:1/fs:((L*100)-1)/fs];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% DEP QPSK %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

l=length(yqpsk);
f=linspace(-fs/2,fs/2,l);%vector de frecuencia
depqpsk=fftshift((abs(fft(yqpsk))).^2)/(l);%DEP bilateral de la se�al QPSK

figure(1)
subplot(3,1,1)
plot(t2,bp);
axis ([0 0.8 -2 2])
legend ('Secuencia de bits pares');
xlabel('t(s)');
subplot(3,1,2) 
plot(t2,bi);
axis ([0 0.8 -2 2])
legend ('Secuencia de bits impares');
xlabel('t(s)');
subplot(3,1,3) 
plot(t2,yqpsk);
axis ([0 0.8])
legend ('Senal modulada QPSK en tiempo');
xlabel('t(s)');



figure(2)
subplot(2,1,1)
plot(t2,yqpsk);
axis ([0 2])
legend (' Senal QPSK en tiempo'); 
xlabel('t(s)');
subplot(2,1,2)
plot(f,depqpsk);
legend (' DEP de Senal QPSK');
xlabel('f(Hz)');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Constelaci�n%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fs2=100;
ts2=0.2;
tb2=0:0.001:0.1-0.001; % Vector de tiempo para la base longitud 100
ucos2=sqrt(2/ts2)*cos(2*pi*fp*tb2);
usin2=sqrt(2/ts2)*sin(2*pi*fp*tb2);  
for k=1:L;
          det5(k)=(ts2)*mean(yqpsk(1+(k-1)*fs2:k*fs2).*ucos2);
          det6(k)=(ts2)*mean(yqpsk(1+(k-1)*fs2:k*fs2).*usin2);
         
end  
figure(3) 
scatter(det5,det6,'filled');
axis([-1 1 -1 1]);
title('Constelacion QPSK')





%-------------------------------------------------
%********************CANAL************************
%-------------------------------------------------

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%        RUIDO DEL CANAL                    %"); 
disp("% Seleccione la potencia de ruido :         %");
disp("% (1)10 W                                   %");
disp("% (2)20 W                                   %");
disp("% (3)30 W                                   %");
disp("% (4)40 W                                   %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	
RUIDO=input("ingrese la opcion: ");%el usuario selcciona potencia de ruido
pause(2)
disp("\n "); 

if RUIDO==1 
		    RUIDO=10;
endif
if RUIDO==2 
        RUIDO=20;
endif
if RUIDO==3    
          RUIDO=30;       
end
if RUIDO==4    
          RUIDO=40;        
end
noiseu=sqrt(RUIDO)*randn(size(yqpsk));
y0=yqpsk+noiseu;% se le suma ruido a la se�al

	figure(4)
	subplot(2,1,1)  
	plot(t2,y0);
  axis ([0 10])
  legend (' Senal QPSK + RUIDO');
  xlabel('t(s)');
	subplot(2,1,2)
	yfrec = (abs(fft(y0)).^2)/(l);
	plot(0:fs/length(y0):fs/2-fs/length(y0),yfrec(1:length(y0)/2))
	legend('DEP Unilateral QPSK + RUIDO');
	xlabel('f(Hz)');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% DETECTOR QPSK%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  for k=1:L;
          det5(k)=mean(y0(1+(k-1)*fs2:k*fs2).*ucos2);
          det6(k)=mean(y0(1+(k-1)*fs2:k*fs2).*usin2);
         
end  

      for k=1:L
                if (det5(k)>0 && det6(k)>0)
                    recibidospar(k)=-1; recibidosimpar(k)=1;
                end
                if (det5(k)>0 && det6(k)<0)
                    recibidospar(k)=1; recibidosimpar(k)=1;
                end
                if  (det5(k)<0 && det6(k)>0)
                    recibidospar(k)=-1; recibidosimpar(k)=-1;
                end
                if  (det5(k)<0 && det6(k)<0)
                    recibidospar(k)=1; recibidosimpar(k)=-1;
                end
      end
%end  
 
rimpar=(1/2)*(recibidosimpar-1);% toman valores 1 y 0 
rpar=(1/2)*(recibidospar-1);% toman valores 1 y 0 

br=[];%bits recuperados

	for i=1:2:length(rimpar)
			br(i)=rimpar(i);%guarda los impares en br
			br(i+1)=rimpar(i);
end

	for i=2:2:length(br)
			br(i)=rpar(i);
end

brr=[];%secuencia de bits
for i=1:length(br)
        switch b(i)
            case 0
                brr=[brr  ceros];
            case 1
                brr=[brr  unos];
           
        end
                
end


	figure(5)
	subplot(2,1,1)  
	plot(t2,bo); 
  axis ([0 10 -2 2])
  legend (' Secuencia de bits original ');
  xlabel('t(s)');
	subplot(2,1,2)
	plot(t2,brr); 
	axis ([0 10 -2 2])
	legend (' Secuencia de bits recuperada ');
  xlabel('t(s)');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%Contelaci�n%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fs2=100;
tb2=0:0.001:0.1-0.001; % Vector de tiempo para la base longitud 100
fb1=10;
for k=1:L;
          det5c(k)=(ts2)*mean(y0(1+(k-1)*fs2:k*fs2).*ucos2);
          det6c(k)=(ts2)*mean(y0(1+(k-1)*fs2:k*fs2).*usin2);
         
end 

figure(6)

scatter(det5c,det6c,2,'filled');
axis([-1 1 -1 1]);
title('Constelacion')

 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%% Pe vs. E/n%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

noise1=sqrt(0.60*RUIDO)*randn(size(yqpsk));
noise2=sqrt(0.75*RUIDO)*randn(size(yqpsk));
noise3=sqrt(0.90*RUIDO)*randn(size(yqpsk));
noise4=noiseu;
noise5=sqrt(2.00*RUIDO)*randn(size(yqpsk));
noise6=sqrt(3.00*RUIDO)*randn(size(yqpsk));
noise7=sqrt(4.00*RUIDO)*randn(size(yqpsk));
noise8=sqrt(5.00*RUIDO)*randn(size(yqpsk)); 
%se�ales mas ruido

y1=yqpsk+noise1;
y2=yqpsk+noise2;
y3=yqpsk+noise3;
y4=y0;%punto introducido por el usuario
y5=yqpsk+noise5;
y6=yqpsk+noise6;
y7=yqpsk+noise7;
y8=yqpsk+noise8;

%y1
for k=1:L;
          det51(k)=mean(y1(1+(k-1)*fs2:k*fs2).*ucos2);
          det61(k)=mean(y1(1+(k-1)*fs2:k*fs2).*usin2);
         
 
                if (det51(k)>0 && det61(k)>0)
                    recibidospar1(k)=-1; recibidosimpar1(k)=1;
                end
                if (det51(k)>0 && det61(k)<0)
                    recibidospar1(k)=1; recibidosimpar1(k)=1;
                end
                if  (det51(k)<0 && det61(k)>0)
                    recibidospar1(k)=-1; recibidosimpar1(k)=-1;
                end
                if  (det51(k)<0 && det61(k)<0)
                    recibidospar1(k)=1; recibidosimpar1(k)=-1;
                end


%y2

          det52(k)=mean(y2(1+(k-1)*fs2:k*fs2).*ucos2);
          det62(k)=mean(y2(1+(k-1)*fs2:k*fs2).*usin2);
         
 


   
                if (det52(k)>0 && det62(k)>0)
                    recibidospar2(k)=-1; recibidosimpar2(k)=1;
                end
                if (det52(k)>0 && det62(k)<0)
                    recibidospar2(k)=1; recibidosimpar2(k)=1;
                end
                if  (det52(k)<0 && det62(k)>0)
                    recibidospar2(k)=-1; recibidosimpar2(k)=-1;
                end
                if  (det52(k)<0 && det62(k)<0)
                    recibidospar2(k)=1; recibidosimpar2(k)=-1;
                end

%y3


          det53(k)=mean(y3(1+(k-1)*fs2:k*fs2).*ucos2);
          det63(k)=mean(y3(1+(k-1)*fs2:k*fs2).*usin2);
         



      
                if (det53(k)>0 && det63(k)>0)
                    recibidospar3(k)=-1; recibidosimpar3(k)=1;
                end
                if (det53(k)>0 && det63(k)<0)
                    recibidospar3(k)=1; recibidosimpar3(k)=1;
                end
                if  (det53(k)<0 && det63(k)>0)
                    recibidospar3(k)=-1; recibidosimpar3(k)=-1;
                end
                if  (det53(k)<0 && det63(k)<0)
                    recibidospar3(k)=1; recibidosimpar3(k)=-1;
                end


%y5



          det55(k)=mean(y5(1+(k-1)*fs2:k*fs2).*ucos2);
          det65(k)=mean(y5(1+(k-1)*fs2:k*fs2).*usin2);
         
 


                if (det55(k)>0 && det65(k)>0)
                    recibidospar5(k)=-1; recibidosimpar5(k)=1;
                end
                if (det55(k)>0 && det65(k)<0)
                    recibidospar5(k)=1; recibidosimpar5(k)=1;
                end
                if  (det55(k)<0 && det65(k)>0)
                    recibidospar5(k)=-1; recibidosimpar5(k)=-1;
                end
                if  (det55(k)<0 && det65(k)<0)
                    recibidospar5(k)=1; recibidosimpar5(k)=-1;
                end


%y6



          det56(k)=mean(y6(1+(k-1)*fs2:k*fs2).*ucos2);
          det66(k)=mean(y6(1+(k-1)*fs2:k*fs2).*usin2);
         


    
                if (det56(k)>0 && det66(k)>0)
                    recibidospar6(k)=-1; recibidosimpar6(k)=1;
                end
                if (det56(k)>0 && det66(k)<0)
                    recibidospar6(k)=1; recibidosimpar6(k)=1;
                end
                if  (det56(k)<0 && det66(k)>0)
                    recibidospar6(k)=-1; recibidosimpar6(k)=-1;
                end
                if  (det56(k)<0 && det66(k)<0)
                    recibidospar6(k)=1; recibidosimpar6(k)=-1;
                end
endfor 






yrecibida1=recibidospar1+j*recibidosimpar1;
yrecibida2=recibidospar2+j*recibidosimpar2;
yrecibida3=recibidospar3+j*recibidosimpar3;
yrecibida4=recibidospar+j*recibidosimpar;
yrecibida5=recibidospar5+j*recibidosimpar5;
yrecibida6=recibidospar6+j*recibidosimpar6;



errores1= size(find([(xpar+j*ximpar) - yrecibida1]),2)/length(yrecibida1);
errores2= size(find([(xpar+j*ximpar) - yrecibida2]),2)/length(yrecibida2);
errores3= size(find([(xpar+j*ximpar) - yrecibida3]),2)/length(yrecibida3);
errores4= size(find([(xpar+j*ximpar) - yrecibida4]),2)/length(yrecibida4);
errores5= size(find([(xpar+j*ximpar) - yrecibida5]),2)/length(yrecibida5);
errores6= size(find([(xpar+j*ximpar) - yrecibida6]),2)/length(yrecibida6);


P=mean(yqpsk.*yqpsk);
EnerProm=P*0.1;%potencia por tiempo de bit

 eta1=(mean(noise1.^2))*2/fs;
 eta2=(mean(noise2.^2))*2/fs;
 eta3=(mean(noise3.^2))*2/fs;
 eta4=(mean(noise4.^2))*2/fs;
 eta5=(mean(noise5.^2))*2/fs;
 eta6=(mean(noise6.^2))*2/fs;

etas=[eta6 eta5 eta4 eta3 eta2 eta1];

EN1=10*log10(EnerProm/eta1); 
EN2=10*log10(EnerProm/eta2);
EN3=10*log10(EnerProm/eta3);
EN4=10*log10(EnerProm/eta4);
EN5=10*log10(EnerProm/eta5);
EN6=10*log10(EnerProm/eta6); 

EN=[EN6 EN5 EN4 EN3 EN2 EN1 ];
SERteorico =2* qfunc(sqrt(0.1*P./etas));
SERpractico= [ errores6 errores5 errores4 errores3 errores2 errores1];


figure(7)
semilogy(EN,SERteorico,'b');
hold on
semilogy(EN,SERpractico,'m.-');  
hold on
semilogy(EN4,errores4,'g*');
grid on
%zoom on
legend('teorico', 'practico', 'usuario');
xlabel('E/N, dB')
ylabel('Tasa de Error por Simbolo')
%axis([0 20 10^-4 1])
title('Pe vs E/n modulacion QPSK') 