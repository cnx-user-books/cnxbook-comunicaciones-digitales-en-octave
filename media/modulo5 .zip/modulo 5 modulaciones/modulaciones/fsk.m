function [] = fsk(x,l)


%funci�n que genera una se�al  FSK
 b=x;% secuencia de bit generada en el programa principal
 L=l;%n�mero de bits generados
%-------------------------------------------------
% se le asigna a cada bit 100 puntos para graficar la secuencia de bits 
nm=100;%n�mero de muestras por bit
unos=ones(1,nm);
ceros=zeros(1,nm);

bo=[];
for i=1:length(b)
        switch b(i)
            case 0
                bo=[bo  ceros];
            case 1
                bo=[bo  unos];
           
        end
                
end
%-------------------------------------------------
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%           Modulaci�n FSK                  %"); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	

disp("%-------------------------------------------------------------%");
disp("%  La frecuencia de muestreo para FSK se fija en 1000 Hz      %"); 
disp("%  El tiempo de bit se fija en 100ms                          %"); 
disp("%  Usted debe seleccionar las frecuencias fa y fb             %");
disp("%  Usted debe seleccionar la potencia de ruido del canal.     %");
disp("%-------------------------------------------------------------%");
disp("%   Recuerde que para que las bases sean ortogonales la       %");
disp("%   distancia entre fa y fb debe ser m�ltiplo de fbit/2       %");
disp("%   La frecuencia de portadora (fc) es (fa+fb)/2              %");
disp("%   Se recomienda que fc este alredeor de los 100 Hz          %");
disp("%-------------------------------------------------------------%");
pause(7)
fa=input("Ingrese la fa en Hz: ");%el usuario introduce la fa
pause(2)
fb=input("Ingrese la fb en Hz: ");%el usuario introduce la fb
pause(2)
disp("\n "); 


%-------------------------------------------------
%%%%%%%% FSK %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%Modulaci�n en frecuencia%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------------------------------------------------- 
fs=1000;%frecuencia muestreo
tb=0:0.001:0.1-0.001;%tiempo de bit 100ms
fbit=10;%frecuencia de bit

baseFSK1=sqrt(2*fbit)*sin(2*pi*fa*tb);
baseFSK2=sqrt(2*fbit)*sin(2*pi*fb*tb);    
long1=length(tb); 

yfsk=[ ];   %se inicializa el arreglo como uno vac�o
for i=1:L
    switch b(i)
				case 1
						yfsk(1+long1*(i-1):long1*i)=[baseFSK1];
            
        case 0
            yfsk(1+long1*(i-1):long1*i)=[baseFSK2];
			   
    end
end
%yfsk se�al psk generada.

%Normalizaci�n de la se�al yfsk 


y2max=abs(max(yfsk));
y2min=abs(min(yfsk));

if y2max>=y2min
    voltnorm=y2max;
elseif y2min>y2max
    voltnorm=y2min;
end

yfsk=yfsk/voltnorm;

t=[0:1/fs:((L*100)-1)/fs];%vector tiempo
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% DEP FSK %%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

l=length(yfsk);
f=linspace(-fs/2,fs/2,l);%vector de frecuencia
depfsk=fftshift((abs(fft(yfsk))).^2)/(l);

figure(1)
subplot(2,1,1)
plot(t,bo);
axis ([0 1 -2 2])
legend (' Secuencia de bits'); 
xlabel('t(s)');
subplot(2,1,2)
plot(t,yfsk);
axis ([0 1])
legend (' Senal FSK en tiempo'); 
xlabel('t(s)');


figure(2)
subplot(2,1,1)
plot(t,yfsk);
axis ([0 2])
legend (' Senal FSK en tiempo'); 
xlabel('t(s)');
subplot(2,1,2)
plot(f,depfsk);
axis ([0 200 0 50])
legend (' DEP de Senal FSK');
xlabel('f(Hz)'); 

 fs1=100;
 dett1=[]; 
 dett2=[];
 
 for k=1:L
           dett1(k)=(1/fbit)*mean(yfsk(1+(k-1)*fs1:k*fs1).*baseFSK1);    
					 dett2(k)=(1/fbit)*mean(yfsk(1+(k-1)*fs1:k*fs1).*baseFSK2);    
	end  

 figure(3) 
scatter(dett1,dett2,'filled');
axis([-2 2 -2 2]);
title('Constelacion FSK')

%-------------------------------------------------
%********************CANAL************************
%-------------------------------------------------

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%        RUIDO DEL CANAL                    %"); 
disp("% Seleccione la potencia de ruido :         %");
disp("% (1)40 W                                   %");
disp("% (2)60 W                                   %");
disp("% (3)80 W                                   %");
disp("% (4)100 W                                  %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	
RUIDO=input("ingrese la opcion: ");%el usuario selcciona la potencia de ruido
pause(2)
disp("\n "); 

if RUIDO==1 
     RUIDO=40;
endif
if RUIDO==2 
        RUIDO=60;
endif
if RUIDO==3    
          RUIDO=80;       
end
if RUIDO==4    
          RUIDO=100;        
end
noiseu=sqrt(RUIDO)*randn(size(yfsk));
y4=yfsk+noiseu;% se le suma ruido a la se�al
	figure(4)
	subplot(2,1,1)  
	plot(t,y4);
	axis ([0 10])
	legend (' Senal FSK + RUIDO');
	xlabel('t(s)');
	subplot(2,1,2)
	yfrec = (abs(fft(y4)).^2)/(l);
	plot(t,yfrec);
	axis ([0 200 0 3000])
	legend ('DEP Unilateral FSK + RUIDO');
	xlabel('f(Hz)');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% DETECTOR FSK %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 

 for k=1:L
           det1(k)=mean(y4(1+(k-1)*fs1:k*fs1).*baseFSK1);    
					 det2(k)=mean(y4(1+(k-1)*fs1:k*fs1).*baseFSK2);    
end  

      for k=1:L
                if det1(k)>det2(k)
                    rec4(k)=1;
                else
                    rec4(k)=0;
                end
      end   

%rec es la secuencia de bit recuperada



br=[];
for i=1:length(rec4)
        switch rec4(i) 
            case 0
                br=[br  ceros];
            case 1
                br=[br  unos];
           
        end
                
end

	figure(5)
	subplot(2,1,1)  
	plot(t,bo); 
	xlabel('Segundos');
	axis([0 10 -2 2]);
  legend (' Secuencia de bits original');
	subplot(2,1,2)
	plot(t,br); 
	xlabel('Segundos');
	axis([0 10 -2 2]);
  legend (' Secuencia de bits recuperada');
	

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# %%%%%%%% Para la probabilidad de error %%%%%%%%%%%
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# 
noise0=sqrt(0.45*RUIDO)*randn(size(yfsk));
noise1=sqrt(0.60*RUIDO)*randn(size(yfsk));
noise2=sqrt(0.75*RUIDO)*randn(size(yfsk));
noise3=sqrt(0.90*RUIDO)*randn(size(yfsk));
noise4=noiseu;
noise5=sqrt(2.00*RUIDO)*randn(size(yfsk));
noise6=sqrt(3.00*RUIDO)*randn(size(yfsk));
noise7=sqrt(4.00*RUIDO)*randn(size(yfsk));
noise8=sqrt(5.00*RUIDO)*randn(size(yfsk)); 
%se�ales m�s ruido


y0=yfsk+noise0;
y1=yfsk+noise1;
y2=yfsk+noise2;
y3=yfsk+noise3;
y5=yfsk+noise5;
y6=yfsk+noise6;
y7=yfsk+noise7;
y8=yfsk+noise8;


# %% Detecci�n de las otras se�ales con ruido %%%%%%
# %%%%%%%necesario para la gr�fica de Pe vs E/n%%%%%%
 

det1=[];
det2=[];


for k=1:L
           det1(k)=mean(y0(1+(k-1)*fs1:k*fs1).*baseFSK1);    
					 det2(k)=mean(y0(1+(k-1)*fs1:k*fs1).*baseFSK2);    
  

                if det1(k)>det2(k)
                    rec0(k)=1;
                else
                    rec0(k)=0;
                end
   


           det1(k)=mean(y1(1+(k-1)*fs1:k*fs1).*baseFSK1);    
					 det2(k)=mean(y1(1+(k-1)*fs1:k*fs1).*baseFSK2);    
 

   
                if det1(k)>det2(k)
                    rec1(k)=1;
                else
                    rec1(k)=0;
                end
     


           det1(k)=mean(y2(1+(k-1)*fs1:k*fs1).*baseFSK1);    
					 det2(k)=mean(y2(1+(k-1)*fs1:k*fs1).*baseFSK2);    



                if det1(k)>det2(k)
                    rec2(k)=1;
                else
                    rec2(k)=0;
                end
   


           det1(k)=mean(y3(1+(k-1)*fs1:k*fs1).*baseFSK1);    
					 det2(k)=mean(y3(1+(k-1)*fs1:k*fs1).*baseFSK2);    
  


                if det1(k)>det2(k)
                    rec3(k)=1;
                else
                    rec3(k)=0;
                end
   


           det1(k)=mean(y5(1+(k-1)*fs1:k*fs1).*baseFSK1);    
					 det2(k)=mean(y5(1+(k-1)*fs1:k*fs1).*baseFSK2);    
  


                if det1(k)>det2(k)
                    rec5(k)=1;
                else
                    rec5(k)=0;
                end
  


           det1(k)=mean(y6(1+(k-1)*fs1:k*fs1).*baseFSK1);    
					 det2(k)=mean(y6(1+(k-1)*fs1:k*fs1).*baseFSK2);    
 

 
                if det1(k)>det2(k)
                    rec6(k)=1;
                else
                    rec6(k)=0;
                end
    


           det1(k)=mean(y7(1+(k-1)*fs1:k*fs1).*baseFSK1);    
					 det2(k)=mean(y7(1+(k-1)*fs1:k*fs1).*baseFSK2);    



                if det1(k)>det2(k)
                    rec7(k)=1;
                else
                    rec7(k)=0;
                end
   


           det1(k)=mean(y8(1+(k-1)*fs1:k*fs1).*baseFSK1);    
					 det2(k)=mean(y8(1+(k-1)*fs1:k*fs1).*baseFSK2);    
  


                if det1(k)>det2(k)
                    rec8(k)=1;
                else
                    rec8(k)=0;
                end
  end  

 

# %%%%%%% Pe vs E/n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  errores0= size(find([b - rec0]),2)/length(rec0);
  errores1= size(find([b - rec1]),2)/length(rec1);
  errores2= size(find([b - rec2]),2)/length(rec2);
  errores3= size(find([b - rec3]),2)/length(rec3);
  errores4= size(find([b - rec4]),2)/length(rec4);
  errores5= size(find([b - rec5]),2)/length(rec5);
  errores6= size(find([b - rec6]),2)/length(rec6);
  errores7= size(find([b - rec7]),2)/length(rec7);
  errores8= size(find([b - rec8]),2)/length(rec8);

 eta0=mean(noise0.^2); 
 eta1=mean(noise1.^2);
 eta2=mean(noise2.^2);
 eta3=mean(noise3.^2);
 eta4=mean(noise4.^2);
 eta5=mean(noise5.^2);
 eta6=mean(noise6.^2);
 eta7=mean(noise7.^2);
 eta8=mean(noise8.^2);
 etas=[eta8 eta7 eta6 eta5 eta4 eta3 eta2 eta1 eta0];
P=mean(yfsk.*yfsk);
EnerProm=P*0.1; 
 
 EN0=10*log10(EnerProm*0.5*fs/eta0);
 EN1=10*log10(EnerProm*0.5*fs/eta1);
 EN2=10*log10(EnerProm*0.5*fs/eta2);
 EN3=10*log10(EnerProm*0.5*fs/eta3);
 EN4=10*log10(EnerProm*0.5*fs/eta4);
 EN5=10*log10(EnerProm*0.5*fs/eta5); 
 EN6=10*log10(EnerProm*0.5*fs/eta6);
 EN7=10*log10(EnerProm*0.5*fs/eta7);
 EN8=10*log10(EnerProm*0.5*fs/eta8);

EN=[EN8 EN7 EN6 EN5 EN4 EN3 EN2 EN1 EN0];
 BERteorico = qfunc(sqrt(0.1*P*fs./(2*etas)));

 BERpractico= [errores8 errores7 errores6 errores5 errores4 errores3 errores2 errores1 errores0];


 figure(6)
 semilogy(EN,BERteorico,'b');
 hold on 
 semilogy(EN,BERpractico,'m.-');
 hold on
 semilogy(EN4,errores4,'g*');
 grid on
 
 legend('teorico', 'practico', 'usuario');
 xlabel('E/N, dB')
 ylabel('Tasa de Error por Simbolo')
 title('Pe vs E/n modulacion FSK') 

end