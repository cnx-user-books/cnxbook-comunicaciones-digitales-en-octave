function [] = psk(x,l)

b=x;% secuencia de bit generada en el programa principal
L=l;%n�mero de bits generados

 

%-------------------------------------------------
%%%%%%%% PSK %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%Modulaci�n de Fase %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%-------------------------------------------------
% se le asigna a cada bit 100 puntos para graficar la secuencia de bits 
nm=100;%n�mero de muestras por bit
unos=ones(1,nm);
ceros=zeros(1,nm);

bo=[];
for i=1:length(b)
        switch b(i)
            case 0
                bo=[bo  ceros];
            case 1
                bo=[bo  unos];
           
        end
                
end
%bo contiene la reperesentaci�n de la secuencia de bits
%cada bit se representa con 100 puntos
%-------------------------------------------------

fs=1000;%frecuencia de muestreo
tb=0:0.001:0.1-0.001; %tiempo para las bases, 100 puntos  
fb=10;%frecuencia de bit; timepo de bit 0.1 seg


disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%           Modulaci�n PSK                 %"); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	

disp("%-------------------------------------------------------------%");
disp("%  La frecuencia de muestreo para PSK se fija en 1000 Hz      %"); 
disp("%  El tiempo de bit se fija en 100ms                          %"); 
disp("%  Usted debe seleccionar la frecuencia de portadora,         %");
disp("%  Usted debe seleccionar la potencia de ruido del canal.     %");
disp("%-------------------------------------------------------------%");
pause(5)
disp("% Introduzca la frecuencia de portadora (fp)                           %");
disp("% La frecuencia debe estar comprendida entre valores de:  10Hz a 500Hz %");
fp=input("Ingrese la fp en Hz: ");%el usuario introduce la fp
pause(2)
disp("\n "); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%PRK%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


uPSK=sqrt(2*fb)*sin(2*pi*fp*tb);%base u1 PSK representada con 100 puntos
long1=length(tb);
ypsk=[];%vector vacio se�al PSK 
for i=1:L
        switch b(i)
            case 1
                ypsk(1+long1*(i-1):long1*i)=[-uPSK];
            case 0
                ypsk(1+long1*(i-1):long1*i)=[uPSK];
        end
                
end
%ypsk se�al PSK generada.
%Normalizaci�n de la se�al ypsk 


y2max=abs(max(ypsk));
y2min=abs(min(ypsk));

if y2max>=y2min
    voltnorm=y2max;
elseif y2min>y2max
    voltnorm=y2min;
end

ypsk=ypsk/voltnorm;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t=[0:1/fs:((L*100)-1)/fs];%vector tiempo
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% DEP PSK %%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

l=length(ypsk);%longitud de la se�al ypsk
f=linspace(-fs/2,fs/2,l);%vector de frecuencia
deppsk=fftshift((abs(fft(ypsk))).^2)/(l);%DEP de la se�al PSK

figure(1)
subplot(2,1,1) 
plot(t,bo);
axis ([0 2 -2 2])
legend (' Secuencia de Bits'); 
xlabel('t(s)');
subplot(2,1,2)
plot(t,ypsk);
axis ([0 2])
legend (' Senal PSK en tiempo'); 
xlabel('t(s)'); 




figure(2)
subplot(2,1,1)
plot(t,ypsk);
axis ([0 2])
legend (' Senal PSK en tiempo'); 
xlabel('t(s)');
subplot(2,1,2)
plot(f,deppsk);
legend (' DEP de Senal PSK');
xlabel('f(Hz)'); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% Constelaci�n %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 
dett1=[];

fs1=100;

for k=1:L
          dett1(k)=(1/fb)*mean(ypsk(1+(k-1)*fs1:k*fs1).*uPSK);    
		      
end   
figure(3) 
scatter(dett1,dett1*0,'filled');
axis([-1 1 -0.6 0.6]);
title('Constelacion PSK')


 
%-------------------------------------------------
%********************CANAL************************
%-------------------------------------------------

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%        RUIDO DEL CANAL                    %"); 
disp("% Seleccione la potencia de ruido :         %");
disp("% (1)40 W                                   %");
disp("% (2)60 W                                   %");
disp("% (3)80 W                                   %");
disp("% (4)100 W                                  %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	
RUIDO=input("ingrese la opci�n de potencia de ruido: ");%el usuario selecciona la potencia de ruido
pause(2)
disp("\n "); 
 
if RUIDO==1 
     RUIDO=40;
endif
if RUIDO==2 
        RUIDO=60;
endif
if RUIDO==3    
          RUIDO=80;       
end
if RUIDO==4    
          RUIDO=100;        
end

noiseu=sqrt(RUIDO)*randn(size(ypsk));
y4=ypsk+noiseu;% se le suma ruido a la se�al
	
	figure(4)
	subplot(2,1,1)  
	plot(t,y4);
  axis ([0 10])
  legend (' Senal PSK + RUIDO');
  xlabel('t(s)');
	subplot(2,1,2)
	yfrec = (abs(fft(y4)).^2)/(l);
	plot(0:fs/length(y4):fs/2-fs/length(y4),yfrec(1:length(y4)/2))
	legend ('DEP Unilateral PSK + RUIDO');
	xlabel('f(Hz)');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Para la probabilidad de error %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rudio generado para la grafica de Pe
noise0=sqrt(0.60*RUIDO)*randn(size(ypsk));
noise1=sqrt(0.70*RUIDO)*randn(size(ypsk));
noise2=sqrt(0.80*RUIDO)*randn(size(ypsk));
noise3=sqrt(0.90*RUIDO)*randn(size(ypsk));
noise4=noiseu;
noise5=sqrt(2.00*RUIDO)*randn(size(ypsk));
noise6=sqrt(3.00*RUIDO)*randn(size(ypsk));
noise7=sqrt(4.00*RUIDO)*randn(size(ypsk));
noise8=sqrt(5.00*RUIDO)*randn(size(ypsk)); 
%se�ales mas ruido
y0=ypsk+noise0;
y1=ypsk+noise1;
y2=ypsk+noise2;
y3=ypsk+noise3;
y4=ypsk+noise4;%potencia introducida manualmente por el usuario
y5=ypsk+noise5;
y6=ypsk+noise6;
y7=ypsk+noise7;
y8=ypsk+noise8;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% DETECTOR YPSK%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
fs1=100;
dett=[]; 
dett2=[];
rec=[];%secuencia de bit recuperada 
for k=1:L
          dett(k)=mean(y4(1+(k-1)*fs1:k*fs1).*-uPSK); 
	              
end   
      for k=1:L
                if dett(k)>0
                    rec(k)=1;
						    else
                    rec(k)=0;
                end
end

 %rec es la secuencia de bit recuperada


br=[];
for i=1:length(rec)
        switch rec(i)
            case 0
                br=[br  ceros];
            case 1
                br=[br  unos];
           
        end
                
end

%br se le asignan 100 puntos a cada bit recuperado para graficarlos

	figure(5)
	subplot(2,1,1)  
	plot(t,bo); 
  axis ([0 10 -2 2])
  legend (' Secuencia de bits original ');
  xlabel('t(s)');
	subplot(2,1,2)
	plot(t,br); 
	axis ([0 10 -2 2])
	legend (' Secuencia de bits recuperada ');
  xlabel('t(s)');
 
 %% Detecci�n de las otras se�ales con ruido %%%%%%
 %%%%%%%necesario para la gr�fica de Pe vs. E/n%%%%%%
 

 fs1=100;

  for k=1:L
           det0(k)=mean(y0(1+(k-1)*fs1:k*fs1).*-uPSK);         

                if det0(k)>0
                    rec0(k)=1;
						    else
                    rec0(k)=0;
                end

           det1(k)=mean(y1(1+(k-1)*fs1:k*fs1).*-uPSK);         
 
   
                if det1(k)>0
                    rec1(k)=1;
						    else
                    rec1(k)=0;
                end



           det2(k)=mean(y2(1+(k-1)*fs1:k*fs1).*-uPSK);         

    
                if det2(k)>0
                    rec2(k)=1;
						    else
                    rec2(k)=0;
                end




           det3(k)=mean(y3(1+(k-1)*fs1:k*fs1).*-uPSK);         

  
                if det3(k)>0
                    rec3(k)=1;
						    else
                    rec3(k)=0;
                end





           det4(k)=mean(y4(1+(k-1)*fs1:k*fs1).*-uPSK);         

      
                if det4(k)>0
                    rec4(k)=1;
						    else
                    rec4(k)=0;
                end



           det5(k)=mean(y5(1+(k-1)*fs1:k*fs1).*-uPSK);         

   
                if det5(k)>0
                    rec5(k)=1;
						    else
                    rec5(k)=0;
                end



           det6(k)=mean(y6(1+(k-1)*fs1:k*fs1).*-uPSK);         

    
                if det6(k)>0
                    rec6(k)=1;
						    else
                    rec6(k)=0;
                end





           det7(k)=mean(y7(1+(k-1)*fs1:k*fs1).*-uPSK);         
 
  
                if det7(k)>0
                    rec7(k)=1;
						    else
                    rec7(k)=0;
                end





           det8(k)=mean(y8(1+(k-1)*fs1:k*fs1).*-uPSK);         

     
                if det8(k)>0
                    rec8(k)=1;
						    else
                    rec8(k)=0;
                end
end

# %%%%%%% Pe vs E/n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  errores0= size(find([b - rec0]),2)/length(rec0);
  errores1= size(find([b - rec1]),2)/length(rec1);
  errores2= size(find([b - rec2]),2)/length(rec2);
  errores3= size(find([b - rec3]),2)/length(rec3);
  errores4= size(find([b - rec4]),2)/length(rec4);
  errores5= size(find([b - rec5]),2)/length(rec5);
  errores6= size(find([b - rec6]),2)/length(rec6);
  errores7= size(find([b - rec7]),2)/length(rec7);
  errores8= size(find([b - rec8]),2)/length(rec8);
 

 eta0=(mean(noise0.^2))*2/fs;
 eta1=(mean(noise1.^2))*2/fs;
 eta2=(mean(noise2.^2))*2/fs;
 eta3=(mean(noise3.^2))*2/fs; 
 eta4=(mean(noise4.^2))*2/fs;
 eta5=(mean(noise5.^2))*2/fs;
 eta6=(mean(noise6.^2))*2/fs;
 eta7=(mean(noise7.^2))*2/fs;
 eta8=(mean(noise8.^2))*2/fs;
 etas=[eta8 eta7 eta6 eta5 eta4 eta3 eta2 eta1 eta0];

P=mean(ypsk.*ypsk);%potencia de la se�al PSK
EnerProm=P*0.1; %energ�a de la se�al P.tb
 
 EN0=10*log10(EnerProm/eta0);
 EN1=10*log10(EnerProm/eta1);
 EN2=10*log10(EnerProm/eta2);
 EN3=10*log10(EnerProm/eta3);
 EN4=10*log10(EnerProm/eta4);
 EN5=10*log10(EnerProm/eta5); 
 EN6=10*log10(EnerProm/eta6); 
 EN7=10*log10(EnerProm/eta7);
 EN8=10*log10(EnerProm/eta8);

EN=[EN8 EN7 EN6 EN5 EN4 EN3 EN2 EN1 EN0];
% Pe= Q(raiz(2*Ep/n)) para PSK
 BERteorico = qfunc(sqrt(2*0.1*P./etas));
 BERpractico= [errores8 errores7 errores6 errores5 errores4 errores3 errores2 errores1 errores0];
# 
 figure(7)
 semilogy(EN,BERteorico,'b');
 hold on 
 semilogy(EN,BERpractico,'m.-');
 hold on
 semilogy(EN4,errores4,'g*');
 grid on
 legend('teorico', 'practico', 'usuario');
 xlabel('E/N, dB')
 ylabel('Tasa de Error por Simbolo')
 title('Pe vs E/n modulacion PSK') 
end