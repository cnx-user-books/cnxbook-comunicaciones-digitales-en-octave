#programa 7 16QAM
clc 
clear all
disp("               Programa 7:Introducci�n Modulaciones(16QAM)           \n "); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%  Se simula  un sistema de modulaci�n M-aria (16-QAM)                %"); 
disp("% constituido por el transmisor, un canal AWGN y un receptor s�ncrono %"); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
pause(2)
%--------------- Preguntas Iniciales-----------------------------------
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%  Antes de realizar la simulaci�n usted debe responder     %");
disp("%          las siguientes preguntas de selecci�n:           %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
pause(2)
disp("\n "); 
disp("%-----------------------------------------------------------%");
disp("%  1.En una se�al pasabanda M-aria (M=2^n) se pueden        %");
disp("%     distinguir:                                           %");
disp("%    (a)n bits diferentes                                   %"); 
disp("%    (b)M s�mbolos diferentes                               %");  
disp("%    (c)n s�mbolos diferentes                               %");  
disp("%-----------------------------------------------------------%");	
input(" ");
r1=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)
tr=0;
if r1=='b'
	tr=tr+1;
else
	disp("Respuesta Incorrecta. Las modulaciones m-araias  se pueden distinguri M s�mbolos diferentes."); 
endif
	
pause(2)

disp("\n "); 
disp("%-----------------------------------------------------------%");
disp("%  2. Los valores que puede tomar un mensaje binario        %");
disp("%     modulado en OOK son:                                  %");
disp("%    (a)V para bit'1' y 0 para bit '0'                      %"); 
disp("%    (b)V para bit '1' y -V para bit '0'                    %");  
disp("%    (c)0 para bit '1' y V para bit '0'                     %");  
disp("%-----------------------------------------------------------%");	

r2=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)
tr=0;
if r2=='a'
	tr=tr+1;
else
	disp("Respuesta Incorrecta.Los valores que puede tomar un mensaje binario");
	disp("modulado en OOK son V para el bit '1' y cero para el bit '0'"); 
	pause(3)
endif



disp("\n "); 
disp("%-----------------------------------------------------------%");
disp("%  3. En una se�al PSK el par�metro de la se�al portadora   %");
disp("%     que se varia es:                                      %");
disp("%    (a)Amplitud                                            %"); 
disp("%    (b)Fase                                                %");  
disp("%    (c)Frecuencia                                          %");  
disp("%-----------------------------------------------------------%");	

r3=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)
tr=0;
if r3=='b'
	tr=tr+1;
else
	disp("Respuesta Incorrecta. El par�metro que se var�a en la portadora PSK es la fase ");
	pause(2)
endif


disp("\n "); 
disp("%-----------------------------------------------------------%");
disp("%  4. Cuando la secuencia de bits cambia de estado la fase  %");
disp("%     de la portadora PSK var�a entre 2 �ngulos defasados:  %");
disp("%    (a)90�                                                 %"); 
disp("%    (b)270�                                                %");  
disp("%    (c)180�                                                %");  
disp("%-----------------------------------------------------------%");	

r4=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)
tr=0;
if r4=='c'
	tr=tr+1;
else
	disp("Respuesta Incorrecta.Los �ngulos estan defasados 180 � ");
	pause(2)
endif


disp("%---------------------------------------------------------------------------------------------------------------------%");
disp("%A continuaci�n se generar� una se�al 16QAM con una velocidad de 1 s�mbolo por segundo,                               %");
disp("%sobre una portadora de  5 Hz, y se observar� lo siguiente: la se�al 16QAM en tiempo y frecuencia,                    %");
disp("%las 16 se�ales  s(t), la contelaci�n de la se�al con y sin rudio y finalmete  se construye la curva de               %");
disp("%Probabilidad de error vs. Potencia de ruido.                                                                         %");
disp("%En la costelaci�n la base u1 est� asociado al Coseno y u2 al Seno.                                                   %");
disp("%Usted podr�  seleccionar la potencia de ruido con la que contaminara la se�al y observar� la se�al contaminada en    %");
disp("%tiempo, frecuencia y su constelaci�n.  La curva de Pe vs.10*log( E/eta) se construye para varios valores de E/eta.   %");
disp("%---------------------------------------------------------------------------------------------------------------------%");

pause(10)
%-------------------------------------------------
%generaci�n de bits
N=4000;
x=randint(1,N);%generaci�n de bits aleatoreos 
%para la contrucci�n de los simbolos.
% se geran 4000 bit para luego generar 1000 simbolos
%-------------------------------------------------
%%%%%%%% I y Q %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%-------------------------------------------------
s=length(x)/4;%longitud de la secuencia de bits
%%%%%%%%%%% Secuencia Quaternaria I,Q%%%%%%%%%%%%%
for i=1:s 
    i1(i)=x(4*i-3)+2*x(4*i-1); %se toman los impares
    q1(i)=x(4*i-2)+2*x(4*i); %se toman los pares
	  I1(i)=x(4*i-3)+2*x(4*i-1);
end
    i2=2*i1-3;% esta variable toma valores -1, 1, -3 y 3 
    q2=2*q1-3;% esta variable toma valores -1, 1, -3 y 3 
%-------------------------------------------------
fs=100;%fecuencia de muestreo, el simbolo se reperesenta con 100 puntos
fc=5;%frecuencia de portadora
tsimb=1;
fsimb=1/tsimb;
t=[0:1/fs:(fs*s-1)/fs];
base=[ones(1,fs)];
I=[];Q=[];

for i=1:s
    I=[I   i2(i)*base]; %representaci�n con 100 puntos de cada simbolo
    Q=[Q   q2(i)*base];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%X16qam= I*u1(-/+)Q*u2%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%-------------------------------------------------
%bases u1 y u2
u1=sqrt(2*fsimb)*cos(2*pi*t*fc);
u2=sqrt(2*fsimb)*sin(2*pi*t*fc);
yorig=I.*u1+Q.*u2;%se�al generada 16 QAM
P=mean(yorig.*yorig);
%-------------------------------------------------
figure (1)
subplot(1,2,1)
plot(t,I);%se�al en tiempo 
axis([0 50 -4 4]);
legend ('Componente Cuadratura');
xlabel('t'); 
subplot(1,2,2)
plot(t,Q);%se�al en tiempo 
axis([0 50 -4 4]);
legend ('Componente Fase ');
xlabel('t');


figure (2)
plot(t,yorig);%se�al en tiempo  
axis([0 10]);
legend ('Senal 16QAM en Tiempo');
xlabel('segundos');
%-------------------------------------------------
l=length(yorig);
f=linspace(-fs/2,fs/2,l);%vector de frecuencia
%DEP DE LAS SE�AL
depqam=fftshift((abs(fft(yorig))).^2)/(l);
%-------------------------------------------------
figure (3)
subplot(2,1,1)
plot(f,depqam);%se�al en tiempo 
legend ('DEP 16QAM ');
xlabel('f(Hz)'); 
subplot(2,1,2)
yfrec = (abs(fft(yorig)).^2)/(l);
plot(0:fs/length(yorig):fs/2-fs/length(yorig),yfrec(1:length(yorig)/2))
legend ('DEP Unilateral 16QAM ');
xlabel('f(Hz)');
%-------------------------------------------------
%diagrama de constelaci�n 
figure(4) 
scatter(I,Q,'filled');
axis([-4 4 -4 4]);
title('Constelacion 16QAM')

%-------------------------------------------------
%-----------Generaci�n de Simbolos-----------------
%-------------------------------------------------



  %SIMBOLO 1%
        simb1=(-3*u1+3*u2); 
        amp1=sqrt(18*2*fsimb);
        fase1=-135;
  %SIMBOLO 2%
        simb2=-u1+3*u2;
        amp2=sqrt(10*2*fsimb);
        fase2=-(atand(1/3))-90;
  %SIMBOLO 3%
        simb3=u1+3*u2;
        amp3=sqrt(10*2*fsimb);
        fase3=-(atand(3));
  %SIMBOLO 4%
        simb4=3*u1+3*u2;
        amp4=sqrt(18*2*fsimb);
        fase4=-45;
  %SIMBOLO 5%
        simb5=-3*u1+u2;
        amp5=sqrt(10*2*fsimb);
        fase5=-(atand(3))-90;
  %SIMBOLO 6%
        simb6=-u1+u2;
        amp6=sqrt(2*2*fsimb);
        fase6=-135;
  %SIMBOLO 7%
        simb7=u1+u2;
        amp7=sqrt(2*2*fsimb);
        fase7=-45;
  %SIMBOLO 8%
        simb8=3*u1+u2;
        amp8=sqrt(10*2*fsimb);
        fase8=-(atand(1/3));
  %SIMBOLO 9%
        simb9=-3*u1-u2;
        amp9=sqrt(10*2*fsimb);
        fase9=(atand(3))+90;
  %SIMBOLO 10%
        simb10=-u1-u2;
        amp10=sqrt(2*2*fsimb);
        fase10=135;
  %SIMBOLO 11%
        simb11=u1-u2;
        amp11=sqrt(2*2*fsimb);
        fase11=45;
  %SIMBOLO 12%
        simb12=3*u1-u2;
        amp12=sqrt(10*2*fsimb);
        fase12=(atand(1/3));
  %SIMBOLO 13%
        simb13=-3*u1-3*u2;
        amp13=sqrt(18*2*fsimb);
        fase13=135;
  %SIMBOLO 14%
        simb14=-u1-3*u2;
        amp14=sqrt(10*2*fsimb);
        fase14=(atand(1/3))+90;
  %SIMBOLO 15%
        simb15=u1-3*u2;
        amp15=sqrt(10*2*fsimb);
        fase15=(atand(3));
  %SIMBOLO 16%
        simb16=3*u1-3*u2;
        amp16=sqrt(18*2*fsimb);
        fase16=45;
		
figure(5)
title('Simbolos en Tiempo') 
subplot(4,4,1)
plot(t,simb1); title('S1')
axis([0 1 -6 6])
subplot(4,4,2)
plot(t,simb2); title('S2')
axis([0 1 -6 6])
subplot(4,4,3)
plot(t,simb3); title('S3')
axis([0 1 -6 6])
subplot(4,4,4)
plot(t,simb4); title('S4')
axis([0 1 -6 6])
subplot(4,4,5)
plot(t,simb5); title('S5')
axis([0 1 -6 6])
subplot(4,4,6)
plot(t,simb6); title('S6')
axis([0 1 -6 6])
subplot(4,4,7)
plot(t,simb7); title('S7')
axis([0 1 -6 6])
subplot(4,4,8)
plot(t,simb8); title('S8')
axis([0 1 -6 6])
subplot(4,4,9)
plot(t,simb9); title('S9')
axis([0 1 -6 6])
subplot(4,4,10)
plot(t,simb10); title('S10')
axis([0 1 -6 6])
subplot(4,4,11)
plot(t,simb11); title('S11')
axis([0 1 -6 6])
subplot(4,4,12)
plot(t,simb12); title('S12')
axis([0 1 -6 6])
subplot(4,4,13)
plot(t,simb13); title('S13')
axis([0 1 -6 6])
subplot(4,4,14)
plot(t,simb14); title('S14')
axis([0 1 -6 6])
subplot(4,4,15)
plot(t,simb15); title('S15')
axis([0 1 -6 6])
subplot(4,4,16)
plot(t,simb16); title('S16')
axis([0 1 -6 6])
EnerProm=10;
%-------------------------------------------------
%********************CANAL************************
%-------------------------------------------------

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%            RUIDO DEL CANAL                %"); 
disp("% Seleccione la potencia de ruido :         %");
disp("% (1)10 W                                   %");
disp("% (2)15 W                                   %");
disp("% (3)20 W                                   %");
disp("% (4)50 W                                   %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	
RUIDO=input("ingrese la opcion: ");%el usuario selcciona nivel de cuantificaci�n

disp("\n "); 

if RUIDO==1 
     RUIDO=10;
endif
if RUIDO==2 
        RUIDO=15;
endif
if RUIDO==3    
          RUIDO=20;       
end
if RUIDO==4    
          RUIDO=50;        
end

noiseu=sqrt(RUIDO)*randn(size(yorig));
noise0=sqrt(0.45*RUIDO)*randn(size(yorig));%potencia es 0.25W
noise1=sqrt(0.60*RUIDO)*randn(size(yorig)); %potencia es 0.33W
noise2=sqrt(0.75*RUIDO)*randn(size(yorig)); %potencia es 0.5W
noise3=sqrt(0.90*RUIDO)*randn(size(yorig)); %potencia es 0.67W
noise4=noiseu;
noise5=sqrt(2.00*RUIDO)*randn(size(yorig)); %potencia es 4W
noise6=sqrt(3.00*RUIDO)*randn(size(yorig)); %potencia es 5W
noise7=sqrt(4.00*RUIDO)*randn(size(yorig)); %potencia es 10W
noise8=sqrt(5.00*RUIDO)*randn(size(yorig)); %potencia es 20W
%se�ales mas ruido
y0=yorig+noise0;
y1=yorig+noise1;
y2=yorig+noise2;
y3=yorig+noise3;
y4=yorig+noise4;
y5=yorig+noise5;
y6=yorig+noise6;
y7=yorig+noise7;
y8=yorig+noise8;


Irec10=y0.*u1;
Irec11=y1.*u1;
Irec12=y2.*u1;
Irec13=y3.*u1;
Irec14=y4.*u1;
Irec15=y5.*u1;
Irec16=y6.*u1;
Irec17=y7.*u1;
Irec18=y8.*u1;
Irec20=y0.*u2;
Irec21=y1.*u2;
Irec22=y2.*u2;
Irec23=y3.*u2;
Irec24=y4.*u2;
Irec25=y5.*u2;
Irec26=y6.*u2;
Irec27=y7.*u2;
Irec28=y8.*u2;

for k=1:s
    det10(k)=mean(Irec10(1+(k-1)*fs:k*fs));
    det11(k)=mean(Irec11(1+(k-1)*fs:k*fs));
    det12(k)=mean(Irec12(1+(k-1)*fs:k*fs));
    det13(k)=mean(Irec13(1+(k-1)*fs:k*fs));
    det14(k)=mean(Irec14(1+(k-1)*fs:k*fs));
    det15(k)=mean(Irec15(1+(k-1)*fs:k*fs));
    det16(k)=mean(Irec16(1+(k-1)*fs:k*fs));
    det17(k)=mean(Irec17(1+(k-1)*fs:k*fs));
    det18(k)=mean(Irec18(1+(k-1)*fs:k*fs));
    det20(k)=mean(Irec20(1+(k-1)*fs:k*fs));
    det21(k)=mean(Irec21(1+(k-1)*fs:k*fs));
    det22(k)=mean(Irec22(1+(k-1)*fs:k*fs));
    det23(k)=mean(Irec23(1+(k-1)*fs:k*fs));
    det24(k)=mean(Irec24(1+(k-1)*fs:k*fs));
    det25(k)=mean(Irec25(1+(k-1)*fs:k*fs));
    det26(k)=mean(Irec26(1+(k-1)*fs:k*fs));
    det27(k)=mean(Irec27(1+(k-1)*fs:k*fs));
    det28(k)=mean(Irec28(1+(k-1)*fs:k*fs)); 
end
detu1=det14;
detu2=det24;

for ii = 1:s
    if (det10(ii)<-2)
        det10(ii)=-3;
    else
        if (det10(ii) > 2)
        det10(ii)=3;
        else
            if (det10(ii)>-2 && det10(ii)<=0)
            det10(ii)=-1;
            else
                if (det10(ii)>0 && det10(ii)<=2)
                    det10(ii)=1;
                end
            end
        end
    end
    if (det20(ii)<-2)
        det20(ii)=-3;
    else
        if (det20(ii)>2)
        det20(ii)=3;
        else
            if (det20(ii)>-2 && det20(ii)<=0)
            det20(ii)=-1;
            else
                if (det20(ii)>0 && det20(ii)<=2)
                    det20(ii)=1;
                end
            end
        end
    end
end
%--------------------------------------------------------------------------

for ii = 1:s
    if (det11(ii)<-2)
        det11(ii)=-3;
    else
        if (det11(ii) > 2)
        det11(ii)=3;
        else
            if (det11(ii)>-2 && det11(ii)<=0)
            det11(ii)=-1;
            else
                if (det11(ii)>0 && det11(ii)<=2)
                    det11(ii)=1;
                end
            end
        end
    end
    if (det21(ii)<-2)
        det21(ii)=-3;
    else
        if (det21(ii)>2)
        det21(ii)=3;
        else
            if (det21(ii)>-2 && det21(ii)<=0)
            det21(ii)=-1;
            else
                if (det21(ii)>0 && det21(ii)<=2)
                    det21(ii)=1;
                end
            end
        end
    end
end
%--------------------------------------------------------------------------

for ii = 1:s
    if (det12(ii)<-2)
        det12(ii)=-3;
    else
        if (det12(ii) > 2)
        det12(ii)=3;
        else
            if (det12(ii)>-2 && det12(ii)<=0)
            det12(ii)=-1;
            else
                if (det12(ii)>0 && det12(ii)<=2)
                    det12(ii)=1;
                end
            end
        end
    end
    if (det22(ii)<-2)
        det22(ii)=-3;
    else
        if (det22(ii)>2)
        det22(ii)=3;
        else
            if (det22(ii)>-2 && det22(ii)<=0)
            det22(ii)=-1;
            else
                if (det22(ii)>0 && det22(ii)<=2)
                    det22(ii)=1;
                end
            end
        end
    end
end
%--------------------------------------------------------------------------

for ii = 1:s
    if (det13(ii)<-2)
        det13(ii)=-3;
    else
        if (det13(ii) > 2)
        det13(ii)=3;
        else
            if (det13(ii)>-2 && det13(ii)<=0)
            det13(ii)=-1;
            else
                if (det13(ii)>0 && det13(ii)<=2)
                    det13(ii)=1;
                end
            end
        end
    end
    if (det23(ii)<-2)
        det23(ii)=-3;
    else
        if (det23(ii)>2)
        det23(ii)=3;
        else
            if (det23(ii)>-2 && det23(ii)<=0)
            det23(ii)=-1;
            else
                if (det23(ii)>0 && det23(ii)<=2)
                    det23(ii)=1;
                end
            end
        end
    end
end
%--------------------------------------------------------------------------

for ii = 1:s
    if (det14(ii)<-2)
        det14(ii)=-3;
    else
        if (det14(ii) > 2)
        det14(ii)=3;
        else
            if (det14(ii)>-2 && det14(ii)<=0)
            det14(ii)=-1;
            else
                if (det14(ii)>0 && det14(ii)<=2)
                    det14(ii)=1;
                end
            end
        end
    end
    if (det24(ii)<-2)
        det24(ii)=-3;
    else
        if (det24(ii)>2)
        det24(ii)=3;
        else
            if (det24(ii)>-2 && det24(ii)<=0)
            det24(ii)=-1;
            else
                if (det24(ii)>0 && det24(ii)<=2)
                    det24(ii)=1;
                end
            end
        end
    end
end
%--------------------------------------------------------------------------

for ii = 1:s
    if (det15(ii)<-2)
        det15(ii)=-3;
    else
        if (det15(ii) > 2)
        det15(ii)=3;
        else
            if (det15(ii)>-2 && det15(ii)<=0)
            det15(ii)=-1;
            else
                if (det15(ii)>0 && det15(ii)<=2)
                    det15(ii)=1;
                end
            end
        end
    end
    if (det25(ii)<-2)
        det25(ii)=-3;
    else
        if (det25(ii)>2)
        det25(ii)=3;
        else
            if (det25(ii)>-2 && det25(ii)<=0)
            det25(ii)=-1;
            else
                if (det25(ii)>0 && det25(ii)<=2)
                    det25(ii)=1;
                end
            end
        end
    end
end
%--------------------------------------------------------------------------
for ii = 1:s
    if (det16(ii)<-2)
        det16(ii)=-3;
    else
        if (det16(ii) > 2)
        det16(ii)=3;
        else
            if (det16(ii)>-2 && det16(ii)<=0)
            det16(ii)=-1;
            else
                if (det16(ii)>0 && det16(ii)<=2)
                    det16(ii)=1;
                end
            end
        end
    end
    if (det26(ii)<-2)
        det26(ii)=-3;
    else
        if (det26(ii)>2)
        det26(ii)=3;
        else
            if (det26(ii)>-2 && det26(ii)<=0)
            det26(ii)=-1;
            else
                if (det26(ii)>0 && det26(ii)<=2)
                    det26(ii)=1;
                end
            end
        end
    end
end
%--------------------------------------------------------------------------
for ii = 1:s
    if (det17(ii)<-2)
        det17(ii)=-3;
    else
        if (det17(ii) > 2)
        det17(ii)=3;
        else
            if (det17(ii)>-2 && det17(ii)<=0)
            det17(ii)=-1;
            else
                if (det17(ii)>0 && det17(ii)<=2)
                    det17(ii)=1;
                end
            end
        end
    end
    if (det27(ii)<-2)
        det27(ii)=-3;
    else
        if (det27(ii)>2)
        det27(ii)=3;
        else
            if (det27(ii)>-2 && det27(ii)<=0)
            det27(ii)=-1;
            else
                if (det27(ii)>0 && det27(ii)<=2)
                    det27(ii)=1;
                end
            end
        end
    end
end
%--------------------------------------------------------------------------
for ii = 1:s
    if (det18(ii)<-2)
        det18(ii)=-3;
    else
        if (det18(ii) > 2)
        det18(ii)=3;
        else
            if (det18(ii)>-2 && det18(ii)<=0)
            det18(ii)=-1;
            else
                if (det18(ii)>0 && det18(ii)<=2)
                    det18(ii)=1;
                end
            end
        end
    end
    if (det28(ii)<-2)
        det28(ii)=-3;
    else
        if (det28(ii)>2)
        det28(ii)=3;
        else
            if (det28(ii)>-2 && det28(ii)<=0)
            det28(ii)=-1;
            else
                if (det28(ii)>0 && det28(ii)<=2)
                    det28(ii)=1;
                end
            end
        end
    end
end

yrecibida0=det10+j*det20;
yrecibida1=det11+j*det21;
yrecibida2=det12+j*det22;
yrecibida3=det13+j*det23;
yrecibida4=det14+j*det24;
yrecibida5=det15+j*det25;
yrecibida6=det16+j*det26;
yrecibida7=det17+j*det27;
yrecibida8=det18+j*det28;

errores0= size(find([(i2+j*q2) - yrecibida0]),2)/length(yrecibida0);
errores1= size(find([(i2+j*q2) - yrecibida1]),2)/length(yrecibida1);
errores2= size(find([(i2+j*q2) - yrecibida2]),2)/length(yrecibida2);
errores3= size(find([(i2+j*q2) - yrecibida3]),2)/length(yrecibida3);
errores4= size(find([(i2+j*q2) - yrecibida4]),2)/length(yrecibida4);
errores5= size(find([(i2+j*q2) - yrecibida5]),2)/length(yrecibida5);
errores6= size(find([(i2+j*q2) - yrecibida6]),2)/length(yrecibida6);
errores7= size(find([(i2+j*q2) - yrecibida7]),2)/length(yrecibida7);
errores8= size(find([(i2+j*q2) - yrecibida8]),2)/length(yrecibida8);

eta0=mean(noise0.^2);
eta1=mean(noise1.^2);
eta2=mean(noise2.^2);
eta3=mean(noise3.^2);
eta4=mean(noise4.^2);
eta5=mean(noise5.^2);
eta6=mean(noise6.^2);
eta7=mean(noise7.^2);
eta8=mean(noise8.^2);
etas=[eta8 eta7 eta6 eta5 eta4 eta3 eta2 eta1 eta0];
EN0=10*log10(EnerProm*0.5*fs/eta0);
EN1=10*log10(EnerProm*0.5*fs/eta1);
EN2=10*log10(EnerProm*0.5*fs/eta2);
EN3=10*log10(EnerProm*0.5*fs/eta3);
EN4=10*log10(EnerProm*0.5*fs/eta4);
EN5=10*log10(EnerProm*0.5*fs/eta5);
EN6=10*log10(EnerProm*0.5*fs/eta6);
EN7=10*log10(EnerProm*0.5*fs/eta7);
EN8=10*log10(EnerProm*0.5*fs/eta8);
EN=[EN8 EN7 EN6 EN5 EN4 EN3 EN2 EN1 EN0];
BERteorico = 3*qfunc(sqrt(0.1*P*fs./etas));
BERpractico= [errores8 errores7 errores6 errores5 errores4 errores3 errores2 errores1 errores0];

figure (6)
subplot(2,1,1)
yu=y4;
plot(t,yu); title ('SENAL c/RUIDO en TIEMPO')
axis([0 500/fs ]);
subplot(2,1,2)
yfrec1 = abs((fft(yu)))/length(yu);
plot(0:fs/length(yu):fs/2-fs/length(yu),yfrec1(1:length(yu)/2)); title ('DEP Contaminada con ruido')
axis([0 20 0 0.2]);
%zoom on

figure(7)

scatter(detu1,detu2,2,'filled');
axis([-4 4 -4 4]);
title('Constelacion')

 hold on
 plot(-2,[-4:0.1:4],'r.')
 hold on
 plot(0,[-4:0.1:4],'r.')
 hold on
 plot(2,[-4:0.1:4],'r.')
 hold on
 plot([-4:0.1:4],-2,'r.')
 hold on
 plot([-4:0.1:4],0,'r.')
 hold on 
 plot([-4:0.1:4],2,'r.')
 

figure(8)
semilogy(EN,BERteorico,'b');
hold on
semilogy(EN,BERpractico,'m.-');
hold on
semilogy(EN4,errores4,'g*');
grid on
%zoom on
legend('teorico', 'practico', 'usuario');
xlabel('E/N, dB')
ylabel('Tasa de Error por Simbolo')
axis([0 20 10^-4 1])
title('Pe vs E/n modulacion 16-QAM') 
disp("\n "); 
disp("%----------------------------------------------------------------------%");
disp("%  5. En una se�al QAM las sinusoides presentes difieren en:           %");
disp("%    (a)Sus amplitudes                                                 %"); 
disp("%    (b)Sus fases                                                      %");  
disp("%    (c)Sus amplitudes y fases                                         %");  
disp("%----------------------------------------------------------------------%");	
r5=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)
if r5=='c'
	tr=tr+1;
else
	disp("Respuesta Incorrecta.Las modulaciones QAM se varia la amplitud y la fase."); 
	pause(2)
endif
disp("\n "); 
disp("%----------------------------------------------------------------------%");
disp("%  6. El ancho de banda de una se�al 16QAM es igual a:                 %");
disp("%    (a)fsimbolo                                                       %"); 
disp("%    (b)fbit/2                                                         %");  
disp("%    (c)2fbit                                                          %");  
disp("%----------------------------------------------------------------------%");	
r6=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)
if r6=='b'
	tr=tr+1;
else
	disp("Respuesta Incorrecta. El ancho de banda de la modulaci�n 16 qam es fbit/2 ."); 
	pause(2)
endif

	if tr>=3 
	disp("  Su total de respuestas correctas fue superior a 3, usted puede ejecutar el m�dulo de Modulaciones");
	else
	disp(" Su total de respuesta correctas fue inferior a 3.  Se recomienda repasar los contenidos de este m�dulo");
	endif
