clc% limpiar pantalla    
clear all 
close all
disp("Programa 3: Introducci�n Ortogonalizaci�n Gram -Schmidt \n "); 

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%  Ejemplo: Transmisi�n Binaria aleatoria NRZp 	                        %"); 
disp("%                                                                       %");  
disp("% El m�todo de Ortogonalizaci�n Gram-Schmidt aplicado para              %");
disp("% la comunicaci�n digital.                                              %");
disp("%                                                                       %"); 
disp("% En este ejemplo se realiza una transmisi�n binaria aleatoria NRZp     %");  
disp("%                                                                       %");  
disp("% Dados ciertos par�metros de la se�al se generan las bases ortogonales.%");
disp("% Finalmente, teniendo las bases calculadas, se halla la constelaci�n.  %");  
disp("%                                                                       %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
pause(10)
disp("\n "); 
%-------------Preguntas Iniciales------------------------------------------------
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%  Antes de realizar la simulaci�n usted debe responder     %");
disp("%          las siguientes preguntas de selecci�n:           %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
pause(5)
disp("\n "); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%  1.� Una se�al NRZP binaria se representa con cu�ntos s�mbolos?  %");
disp("%    (a)4 S�mbolos                                                 %"); 
disp("%    (b)3 S�mbolos                                                 %");  
disp("%    (c)2 S�mbolos                                                 %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
input(" ");
r1=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(3)
tr=0;
if r1=='c'
	tr=tr+1;
else
	disp("Respuesta Incorrecta. La correcta en la opcion c 2 Simbolos");
	pause(3)
endif

disp("\n "); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%  2. Para este ejemplo el n�mero de bases debe ser:        %");
disp("%    (a)=2                                                  %"); 
disp("%    (b)<=2                                                 %");  
disp("%    (c)>2                                                  %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	

r2=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(3)
if r2=='b'
	tr=tr+1;
	else
		disp("Respuesta Incorrecta. La correcta es la opci�n b <=2 Bases, ya que ");
		disp(" si se representa la se�al NRZp con 2 s�mbolos (Sm) el n�mero de bases (Un) ");
		disp(" debe ser menor al n�mero de se�ales Sm ");
		pause(4)
endif

disp("\n "); 

disp("\n "); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("% 3. Dos bases son ortonormales si la integral de 0 a T de uj*uk dt es igual a: %");
disp("%    (a)0 cuando j es diferente de k y 1 cuando j=k                             %"); 
disp("%    (b)1 cuando j es diferente de k y 0 cuando j=k                             %"); 
disp("%    (c)1 para todo   j=k                                                       %"); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	

r3=input("respuesta:", '%c');%el usuario introduce su respuesta
pause(3)
if r3=='a'
	tr=tr+1;
	else
		disp("Respuesta Incorrecta. La correcta es la opcion a ");
		disp(" Es importante mencionar que las bases deben tener energ�a unitaria (E=1)");
  pause(6)
endif

disp("\n "); 

pause(3)

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
disp("%       Ejecuci�n del ejemplo                                           %");  
disp("%    Introduzca el tiempo de s�mbolo (seg), Frecuencia de muestreo(Hz)  %");
disp("%   Se recomienda colocar ts=1seg y fm=10Hz                             %"); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	

tsimb=input("Tiempo de s�mbolo:");%el usuario introduce el tiempo de s�mbolo
pause(2)
disp("\n "); 
fs=input("Introduzca la Frecuencia de muestreo:");%el usuario introduce la frecuencia de muestreo
pause(2)
disp("\n "); 

nro=2;%son 2 s�mbolos por que la se�al es NRZp
t=[0:1/fs:tsimb-(1/fs)];
L=length(t);

%----------s�mbolo 1------------------------------------
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%    S�mbolos                                       %"); 
disp("% Usted debe fijar la amplitud del s�mbolo 1        %");
disp("% recuerde que la amplitud de s1 = V y la de s2 =-V %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
pause(3)
A=input("Amplitud s�mbolo 1 :");%el usuario introduce la amplitud del s�mbolo
pause(2)

   s1 = A*[ones(1,L)]; % Generaci�n del s�mbolo 1
 %--------------Simbolo 2------------------------------
  A2= -A;
  s2 = A2*[ones(1,L)];% Generaci�n del s�mbolo 2

 %C�lculo de energ�as del s�mbolo 1 y 2
 E1=(L/fs)*mean(s1.*s1);
 E2=(L/fs)*mean(s2.*s2);

%Gr�ficas de los s�mbolos
figure (1)
subplot(1,2,1)
plot(t,s1); 
legend ('Simbolo 1');
xlabel('segundos');
ylim([-(A+5) (A+5)])
subplot(1,2,2)
plot(t,s2);
legend ('Simbolo 2');
xlabel('segundos');
ylim([-(A+5) (A+5)])
%-------------------------------------------------
%Generando las bases
%-------------------------------------------------
%generaci�n de u1
if E1 == 0, 
     u1 = [zeros(1,L)];;
 else
     if E1 < 10^-3,
         u1 = [zeros(1,L)];;
     else
         u1 = s1/sqrt(E1) ;%u1 es s1 entre la norma  que es la raiz de la energia s1
     end
end
y=L/fs;

%generaci�n de u2 
integral = mean(s2.*u1)*(L/fs); % <s2.u1>

 if abs(integral) < 10^-3,
     integral = 0;
end
u2num = s2-(u1*integral);%s2-<s2.u1>.u1
Eu2num = (L/fs)*mean(u2num.*u2num);%norma
if Eu2num ==  0,
    u2 = [zeros(1,L)];;
else
    if Eu2num < 10^-3,
        u2 = [zeros(1,L)];
    else
        u2 = u2num/(sqrt((L/fs)*mean(u2num.*u2num)));
    end
end

if u1  == [zeros(1,L)],
    U1 = u2;
    U2 =  [zeros(1,L)];
else
    U1 = u1;
    U2 = u2;
end 
%Gr�ficas de las Bases
figure (2)
subplot(1,2,1)
plot(t,U1); 
legend ('Base 1');
xlabel('segundos'); 
subplot(1,2,2)
plot(t,U2);
legend ('Base 2');
xlabel('segundos');

%%%% Se�al NRZp

 N=100;
 b=randint(1,N,2);     
 long=length(u1);
 senal=[];
 for a=1:N
switch b(a)
        case 0
          senal(1+long*(a-1):long*a)=s1;
        case 1
           senal(1+long*(a-1):long*a)=s2;
       
    end
 end

l=length(senal);
X=fftshift(((abs(fft(senal))).^2)/l); 
t1=(0:(l)-1)/fs;	  %Se genera el vector de tiempo asociado a Y
figure (3)
plot(t1,senal); 
ylim([-(A+5) (A+5)])
legend ('Senal NRZp');
xlabel('segundos');
%----Constelaci�n------------
f1=-fs/2:fs/l:fs/2-fs/l; 
figure (4)
plot(f1,X);
legend (' DEP de Senal NRZp');
xlabel('Hz');


 x1= (L/fs)*mean(U1.*s1); 
 y1= (L/fs)*mean(U2.*s1);
 x2= (L/fs)*mean(U1.*s2);
 y2= (L/fs)*mean(U2.*s2);


figure (5)
plot(x1,y1,'*',x2,y2,'*')
legend ('Constelacion, Leyenda:');
axis([x2-5, x1+5, y2-5, y1+5]) 
pause(30)

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%                     Autoevaluaci�n          	                        %"); 
disp("%                                                                       %");  
disp("% A partir de los resultados obtenidos en las gr�ficas se le realizar�n %");
disp("% una serie de preguntas para comprobar su comprensi�n sobre los        %");
disp("% resultados arrojados en la simulaci�n.                                %"); 
disp("%                                                                       %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	

pause(10)
disp("\n "); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%  4.La base obtenida tiene energ�a:                        %");
disp("%    (a)1                                                   %"); 
disp("%    (b)1.41                                                %");  
disp("%    (c)0.707                                               %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
r4=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(5)

if r4=='a'
	tr=tr+1;
else
	disp("Reflexione. Su respuesta es incorrecta, recuerde que la energia de las bases es unitaria.");
	pause(6)
endif

disp("\n ");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%  5.En la Constelaci�n, al elevar al cuadrado la distancia entre el origen%");
disp("%  y un s�mbolo se obtiene :                                               %");
disp("%   (a)La energ�a de la base                                               %"); 
disp("%   (b)La energ�a del s�mbolo                                              %"); 
disp("%   (c)El tiempo de s�mbolo                                                %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
r5=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(3)

if r5=='b'
	tr=tr+1;
else
	disp(" Su respuesta es incorrecta. La distancia al cuadrado representa la energ�a del s�mbolo.");
	pause(4)
endif
 
disp("\n ");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%  6.En la DEP de la senal NRZp el primer corte corresponde a:             %");
disp("%   (a)Al tiempo de bit                                                    %"); 
disp("%   (b)Al inverso del tiempo de bit                                        %"); 
disp("%   (c)2 veces el tiempo de bit                                            %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
r6=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(3)
 
if r6=='b'  
	tr=tr+1;
else
	disp(" Su respuesta es incorrecta. El primer corte corresponde al inverso del tiempo de bit.");
	pause(4)
endif

if tr>=4 
	disp("  Su total de respuesta correctas fue superior a 4. Puede ejecutar el m�dulo Gram -Schimidt ");
else
	disp(" Su total de respuesta correctas fue inferior a 4. Debe repasar los contenidos de este m�dulo");
	endif
	
