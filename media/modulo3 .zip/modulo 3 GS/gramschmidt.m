%Generaci�n de las 4 se�ales Sk
clc% limpiar pantalla 
clear all
close all
disp("Programa 4: Ortogonalizaci�n Gram -Schmidt \n "); 

disp("%----------------------------------------------------------%")
disp("%   Este programa premite definir hasta 4 se�ales sk(t)    %")
disp("%que representar�n las se�ales de energ�a y en base a ellas%")
disp("%determinar las bases (m�ximo 2 bases)utilizando el m�todo %")
disp("% de ortogonalizaci�n Gram-Schmidt.                        %")
disp("%----------------------------------------------------------%")
pause(5)
disp("%----------------------------------------------------------%")
disp("%  Usted debe indicar:                                    %")
disp("%  - N�mero de Simbolos (sk) que usar� (2,3 o 4)           %")
disp("%  Las se�ales sK pueden ser:                              %")
disp("%   a) Sinusoides (fijar�a frecuencia, amplitud y fase)    %")
disp("%   b) Se�al nula (puros ceros durante todo tb)            %")
disp("%   c) Pulsos constantes durante todo tb (1/fb) Tipo NRZ   %")
disp("%   d) Pulsos 50% prendido y 50% apagado(Tipo RZ)          %")
disp("%   e) Pulsos Manchester                                   %")
disp("%  Tambi�n debe definir la Frecuencia de muestreo (fs)     %")
disp("%  y el tiempo de bit (tb)                                 %")
disp("%----------------------------------------------------------%")
pause(7)
disp("% Se Sugiere que use ts�mbolo=1, f muestreo=10  si sus sk no son sinusoides.%")
disp("% Para sinusoides use ts�mbolo=5, f muestreo=100  y fc de la sinusoide=10   %")
pause(2)
input(" ");
nro=input(" Introduzca el n�mero de s�mbolos a utilizar sk (2-4):");%el usuario introduce el n�mero de s�mbolos
pause(3)
fs=input(" Introduzca la Frecuencia de muestreo (Hz):");%el usuario introduce la frecuencia del simbolo
pause(3)
tsimb=input(" Introduzca el Tiempo de simbolo (s):");%el usuario introduce el tiempo de simbolo
pause(3)
disp("\n "); 
%-----Generaci�n del vector de tiempo-------------
t=[0:1/fs:tsimb-(1/fs)];
L=length(t);

%----------s�mbolo 1------------------------------------
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%   S1: S�mbolo 1                             %"); 
disp("% Selecciones el tipo de se�al                %");
disp("% (0) DC 0                                    %");
disp("% (1) Pulso                                   %");
disp("% (2) Medio Pulso                             %");
disp("% (3) Manchester                              %");
disp("% (4) Coseno                                  %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
onda=input("Tipo de se�al s1:");%el usuario introduce el tipo de s�mbolo
pause(3)
A=input("Amplitud s1:");%el usuario introduce la amplitud del simbolo
pause(3)
if (onda == 4)
fase=input("Fase s1 en RADIANES:");%el usuario introduce la fase del s�mbolo
pause(3)
fc=input("Frecuencia s1 en Hz:");%el usuario introduce la frecuencia del s�mbolo
pause(3)
disp("\n "); 
endif

switch onda
 case 0
   s1 =   [zeros(1,L)];
 case 1
   s1 = A*[ones(1,L)];
 case 2
   s1 = A*[ones(1,L/2) zeros(1,L/2)];
 case 3
   s1 =  A*[ones(1,L/2) -ones(1,L/2)];
  case 4
   s1 =  A*cos(2*pi*fc*t+fase);
end
%--------------S�mbolo 2------------------------------
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%   S2: S�mbolo 2                             %"); 
disp("% Selecciones el tipo de se�al                %");
disp("% (0) DC 0                                    %");
disp("% (1) Pulso                                   %");
disp("% (2) Medio Pulso                             %");
disp("% (3) Manchester                              %");
disp("% (4) Coseno                                  %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
onda2=input("Tipo de se�al s2:");%el usuario introduce el tipo de s�mbolo
pause(3)
A2=input("Amplitud s2:");%el usuario introduce la amplitud del s�mbolo
pause(3)
if (onda2 == 4)
fase2=input("Fase s2 en RADIANES:");%el usuario introduce la fase del s�mbolo
pause(3)
fc2=input("Frecuencia s2 en Hz:");%el usuario introduce la frecuencia del s�mbolo
pause(3)
disp("\n "); 
endif


switch onda2
		case 0
   s2 =   [zeros(1,L)];
 case 1
  s2 = A2*[ones(1,L)];
 case 2
   s2 = A2*[ones(1,L/2) zeros(1,L/2)];
 case 3
  s2 =  A2*[ones(1,L/2) -ones(1,L/2)];
  case 4
  s2 =  A2*cos(2*pi*fc2*t+fase2);
 end
%si se introducen  2 simbolos 
 if nro == 2,
   s3 = [zeros(1,L)];
   s4 = [zeros(1,L)];
	A3=A;
	A4=A;
 else
%--------S�mbolo 3--------------------------------
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%   S3: S�mbolo 3                             %"); 
disp("% Selecciones el tipo de se�al                %");
disp("% (0) DC 0                                    %");
disp("% (1) Pulso                                   %");
disp("% (2) Medio Pulso                             %");
disp("% (3) Manchester                              %");
disp("% (4) Coseno                                  %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
onda3=input("Tipo de se�al s3:");%el usuario introduce el tipo de s�mbolo
pause(3)
A3=input("Amplitud s3:");%el usuario introduce la amplitud del s�mbolo
pause(3)
if (onda3 == 4)
fase3=input("Fase s3 en RADIANES:");%el usuario introduce la fase del s�mbolo
pause(3)
fc3=input("Frecuencia s3 en Hz:");%el usuario introduce la frecuencia del s�mbolo
pause(3)
disp("\n "); 
endif

 
   switch onda3
    case 0
     s3 = [zeros(1,L)];
    case 1
      s3 = A3*[ones(1,L)];
    case 2
     s3 = A3*[ones(1,L/2) zeros(1,L/2)];
    case 3
     s3 = A3*[ones(1,L/2) -ones(1,L/2)];
    case 4
      s3 = A3*cos(2*pi*fc3*t+fase3);
   end
   if nro == 3,
   s4 = [zeros(1,L)];
  A4=A;
else

%--------S�mbolo 4------------------------------------

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%   S4: S�mbolo 4                             %"); 
disp("% Usted debe fijar los par�metros de la se�al%");
disp("% (0) DC 0                                    %");
disp("% (1) Pulso                                   %");
disp("% (2) Medio Pulso                             %");
disp("% (3) Manchester                              %");
disp("% (4) Coseno                                  %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
onda4=input("Tipo de se�al s4:");%el usuario introduce el tipo de s�mbolo
pause(3)
A4=input("Amplitud s4:");%el usuario introduce la amplitud del s�mbolo
pause(3)
if (onda4 == 4)
fase4=input("Fase s4 en RADIANES:");%el usuario introduce la fase del simbolo
pause(3)
fc4=input("Frecuencia s4 en Hz:");%el usuario introduce la frecuencia del s�mbolo
pause(3)
disp("\n "); 
endif

     switch onda4
       case 0
         s4 = [zeros(1,L)];
       case 1
         s4 = A4*[ones(1,L)];
       case 2
         s4 = A4*[ones(1,L/2) zeros(1,L/2)];
       case 3
         s4 = A4*[ones(1,L/2) -ones(1,L/2)];
       case 4
         s4 = A4*cos(2*pi*fc4*t+fase4);
      end
   end
 end
 %C�lculo de energ�as
 E1=(L/fs)*mean(s1.*s1)
 E2=(L/fs)*mean(s2.*s2)
 E3=(L/fs)*mean(s3.*s3)
 E4=(L/fs)*mean(s4.*s4)

%generando las bases
if E1 == 0, 
     u1 = [zeros(1,L)];;
 else
     if E1 < 10^-3,
         u1 = [zeros(1,L)];;
     else
         u1 = s1/sqrt(E1);%se genera la base 1
     end
end
integral = mean(s2.*u1);
if abs(integral) < 10^-3,
    integral = 0;
end
%se genera la base 2
u2num = s2-(u1*(L/fs)*integral);%s2-<s2.u1>u1
Eu2num = (L/fs)*mean(u2num.*u2num);
if Eu2num ==  0,
    u2 = [zeros(1,L)];;
else
    if abs(Eu2num) < 10^-3,
        u2 = [zeros(1,L)];
    else
        u2 = u2num/(sqrt((L/fs)*mean(u2num.*u2num)));%se gener� la base 2 con el smbolo 2
    end
end
%Suponiendo que el paso anterior dio u2 =0 pero hay un s3 
if u2 ==  [zeros(1,L)],
        integral = mean(s3.*u1);
        if abs(integral) < 10^-3,
              integral = 0;
        end
        u2num = s3-(u1*(L/fs)*integral);
        Eu2num = (L/fs)*mean(u2num.*u2num);
        if Eu2num ==  0,
              u2 = [zeros(1,L)];
       else
            if abs(Eu2num) < 10^-3,
                  u2 =  [zeros(1,L)];
             else
                  u2 = u2num/(sqrt((L/fs)*mean(u2num.*u2num)));%se genera la base 2 con el s3
             end
      end
end
%Suponiendo que el paso anterior dio u2 =0 pero hay un s4
if u2 ==  [zeros(1,L)],
        integral = mean(s4.*u1);
        if abs(integral) < 10^-3,
              integral = 0;
        end
        u2num = s4-(u1*(L/fs)*integral);
        Eu2num = (L/fs)*mean(u2num.*u2num);
        if Eu2num ==  0,
              u2 = [zeros(1,L)];
       else
            if abs(Eu2num) < 10^-3,
                  u2 =  [zeros(1,L)];
             else
                  u2 = u2num/sqrt((L/fs)*mean(u2num.*u2num));%se genera la base 2 con s4
             end
      end
end

if u1  == [zeros(1,L)],
    U1 = u2;
    U2 =  [zeros(1,L)];
else
    U1 = u1;
    U2 = u2;
end
%-------------------------------------------------
%Gr�ficas de los s�mbolos


figure (1)
plot(t,s1); 
legend ('S1(t)');
ylim([-(A+2) (A+2)])
xlabel('segundos');
figure (2)
plot(t,s2);
legend ('S2(t)');
xlabel('segundos');
ylim([-(A2+2) (A2+2)])
figure (3)
plot(t,s3);
legend ('S3(t)');
xlabel('segundos');
ylim([-(A3+2) (A3+2)])
figure (4)
plot(t,s4);
legend ('S4(t)');
xlabel('segundos');
ylim([-(A4+2) (A4+2)])
%Gr�fica de las Bases
figure (5)
subplot(1,2,1)
plot(t,U1);
legend ('Base U1');
xlabel('segundos');
subplot(1,2,2)
plot (t,U2);
legend ('Base U2');
xlabel('segundos');
%-------------------------------------------------------------

  %Generaci�n de la se�al
N=100;
b=randint(1,N,2);    
long=length(u1);
senal=[];
%si nro=2 s�lo s1 y s2
if nro==2
 for i=1:N
switch b(i)
        case 0
          senal(1+long*(i-1):long*i)=s1;
        case 1
           senal(1+long*(i-1):long*i)=s2;
    end
end

%----Constelaci�n-----
 x1= (L/fs)*mean(u1.*s1); 
 y1= (L/fs)*mean(u2.*s1);
 x2= (L/fs)*mean(u1.*s2);
 y2= (L/fs)*mean(u2.*s2);

figure (6)
plot(x1,y1,'*',x2,y2,'*');
legend ('Constelacion');
axis([-100, 100, -100, 100]) 
endif

%si nro=3 s�lo s1  s2 y S3
if nro==3
for i=1:N
switch b(i)
        case 0
          senal(1+long*(i-1):long*i)=s1;
        case 1
           senal(1+long*(i-1):long*i)=s2;
        case 2
           senal(1+long*(i-1):long*i)=s3;
    end
end
%----Constelaci�n---------------------------------
 x1= (L/fs)*mean(u1.*s1); 
 y1= (L/fs)*mean(u2.*s1);
 x2= (L/fs)*mean(u1.*s2);
 y2= (L/fs)*mean(u2.*s2);
 x3= (L/fs)*mean(u1.*s3);
 y3= (L/fs)*mean(u2.*s3);
figure (6)
plot(x1,y1,'*',x2,y2,'*',x3,y3,'*');
legend ('Constelacion');
axis([-100, 100, -100, 100])
endif

if nro==4

 for i=1:N
switch b(i)
        case 0
          senal(1+long*(i-1):long*i)=s1;
        case 1
           senal(1+long*(i-1):long*i)=s2;
        case 2
           senal(1+long*(i-1):long*i)=s3;
        case 3
           senal(1+long*(i-1):long*i)=s4;
    end
 end

    %----Constelaci�n---------------------------------
 x1= (L/fs)*mean(u1.*s1); 
 y1= (L/fs)*mean(u2.*s1);
 x2= (L/fs)*mean(u1.*s2);
 y2= (L/fs)*mean(u2.*s2);
 x3= (L/fs)*mean(u1.*s3);
 y3= (L/fs)*mean(u2.*s3);
 x4= (L/fs)*mean(u1.*s4);
 y4= (L/fs)*mean(u2.*s4);
figure (6)
plot(x1,y1,'*',x2,y2,'*',x3,y3,'*',x4,y4,'*');
legend ('Constelacion leyenda:');
axis([-100, 100, -100, 100])
endif
 
%-------------------------------------------------
potencia=mean(senal.*senal);
X=fftshift(fft(senal));
MX=abs(X).^2;
P=length(MX);
MX=MX/P;
f=-fs/2:fs/P:fs/2-fs/P; 
l=length (senal);
t1=(0:(l)-1)/fs;	  %Se genera el vector de tiempo asociado a la se�al
figure (7)
plot(t1,senal); 
legend ('Senal Resultante en Tiempo');
xlabel('segundos');
figure (8)
plot(f,MX);
legend ('Senal Resultante en Frecuencia');
xlabel('Hz');
