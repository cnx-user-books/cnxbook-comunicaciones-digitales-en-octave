%#programa 2 DPCM 
clc% limpiar pantalla 
clear all 
close all
disp("Programa 2:  PCM-DPCM \n "); 

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%   Selecci�n de se�al de voz               %"); 
disp("% (1)Femenina    (FS=44100 HZ)              %");
disp("% (2)Masculina   (FS=44100 HZ)              %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
input(" ");
v=input("ingrese la opci�n: ");%el usuario selcciona la se�al de voz
pause(2)
disp("\n "); 
%%%%%%%%Se�al Femenina%%%%%%%
if (v==1)
[Y,FS, BITS] = wavread('femenina1.wav');
% wavread('pcmfemenino.wav') 
%abre un archivo de audio y guarda las muestras en el vector Y , FS frecuencia del mensaje
Y=Y(:,1)';
Y=Y(31000:62000);
endif
%%%%%%%%%Se�al masculina%%%%%%
if (v==2)
[Y,FS, BITS] = wavread('maculina1.wav');
% wavread('pcmfemenino.wav') 
%abre un archivo de audio y guarda las muestras en el vector Y , FS frecuencia del mensaje
Y=Y(:,1)';
Y=Y(37000:90000);
endif

%--------------------------------
m=mean (Y);%obtiene el promedio de Y
Y=Y-m; %elimina el nivel DC de la se�al
l=length(Y);% Retorna la longitud de  Y 
Y=Y(1 : (l));
t=(0:(l)-1)/FS;	 %vector tiempo
f=linspace(-FS/2,FS/2,l);%vector de frecuencia

% Normalizaci�n de la se�al

y2max=abs(max(Y));
y2min=abs(min(Y));

if y2max>=y2min
    voltnorm=y2max;
elseif y2min>y2max
    voltnorm=y2min;
end

Y=Y/voltnorm;
depy=fftshift((abs(fft(Y))).^2)/l;  %DEP de Y (se�al original)

%------------------------------------------------------ 
%MEN� PARA EL USUARIO , ELECCI�N DE FRECUENCIAS DE MUESTREO
disp("Programa 2: DPCM: Differential Pulse Code Modulation \n "); 

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%             Muestreo                      %"); 
disp("% Seleccione la Frecuencia de muestreo(Hz): %");
disp("% (1)44100                                  %");
disp("% (2)22050                                  %");
disp("% (3)8820                                   %");
disp("% (4)1102                                   %");
disp("% (5)441                                    %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
fmu=input("ingrese la opci�n: ");%el usuario selcciona fm
pause(2)
disp("\n "); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% MUESTREO%%%%%%%%%%%%%%%%%%%%%%%%%%
% Se muestrea la se�al permitiendo al usuario 	 %		
% escoger la frecuencia original(44100)o : 			 %
% FS/2, FS/5, FS/40 o la FS/100. 								 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (fmu==1) 
	Y1=Y;
	l1=length(Y1);
	t1=t;	  %Se genera el vector de tiempo asociado a Y1
	f1=f;
	k=1;
endif 

if (fmu==2)
	Y1=downsample(Y,2);
	l1=length(Y1);
	fs1=22050;
	t1=(0:(l1)-1)/fs1;	  %Se genera el vector de tiempo asociado a Y2
	f1=linspace(-fs1/2,fs1/2,l1); %Se genera el vector frecuencia asociado a FFT(Y2);
	
endif

if (fmu==3) 
	Y1=downsample(Y,5);
	l1=length(Y1);
	fs1=8820;
	t1=(0:(l1)-1)/fs1;	  %Se genera el vector de tiempo asociado a Y3
	f1=linspace(-fs1/2,fs1/2,l1); %Se genera el vector frecuencia asociado a FFT(Y3)

endif


if (fmu==4)
	Y1=downsample(Y,40);
	l1=length(Y1);
	fs1=1102;
	t1=(0:(l1)-1)/fs1;	  %Se genera el vector de tiempo asociado a Y4
	f1=linspace(-fs1/2,fs1/2,l1); %Se genera el vector frecuencia asociado a FFT(Y4)
endif 

if (fmu==5) 
	Y1=downsample(Y,100);
	l1=length(Y1);
	fs1=441;
	t1=(0:(l1)-1)/fs1;	  %Se genera el vector de tiempo asociado a Y5
	f1=linspace(-fs1/2,fs1/2,l1); %Se genera el vector frecuencia asociado a FFT(Y5)
endif

Y1=Y1(1 : (l1));
 
depy1=fftshift((abs(fft(Y1))).^2)/l1;  %DEP de Y1 (se�al muestreada)
%-------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%Gr�ficas%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Se�al original y  muestreada en tiempo   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
subplot (2,1,1)
plot(t,Y)		% Grafica la se�al original
legend ('Senal de voz Original');
xlabel('segundos');
subplot (2,1,2)
plot(t1,Y1)		% Grafica la se�al muestreada
legend ('Senal de voz Muestreada');
xlabel('segundos');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DEP Se�al original y  muestreada 				 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	figure (2)
	subplot (2,1,1)
	plot(f,depy)
	legend ('DEP Senal Original');
  xlabel('Frecuencia Hz');
	subplot (2,1,2)
	plot(f1,depy1)
	legend ('DEP Senal Muestreada');
  xlabel('Frecuencia Hz');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%CUANTIFICACION%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
 disp("%             Cuantificaci�n                 %"); 
 disp("% Seleccione los niveles de Cuantificaci�n:  %");
 disp("% (1)2                                       %");
 disp("% (2)4                                       %");
 disp("% (3)8                                       %");
 disp("% (4)16                                      %");
 disp("% (5)32                                      %");
 disp("% (6)64                                      %");                                 
 disp("% (7)128                                     %");
 disp("% (8)256                                     %");
 disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	
 bit=input("ingrese la opci�n: ");%el usuario selcciona nivel de cuantificaci�n
 pause(2)
 disp("\n "); 

len=(2^bit);%niveles de cuantificaci�n
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%   El nivel de cuantificaci�n seleccionado es tanto para PCM como DPCM%");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
 pause(2)

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%             Orden Del Predictor           %"); 
disp("%     Seleccione un orden                   %");
disp("% (1)2do orden                              %");
disp("% (2)3er orden                              %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n")	

ord=input("ingrese la opci�n: ");%el usuario selcciona el orden 
pause(2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%CUANTIFICACION PCM%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 no_qs = len;
 in = Y1;
 qstep = 2/no_qs;

 for ii = 1:no_qs
    range(ii) = -1 + (ii-1)*qstep;
 end
 out = zeros(size(in));
 for ii = no_qs:(-1):1
     out = out + (in>=range(ii));
 end
 out = out - 1;
 out = (out) * qstep + (-1 + qstep/2);
 squan=out;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%DPCM%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp("\n "); 
disp("Estructura  de DPCM : \n")
disp("\n "); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%                       e                   quant                      %");
disp("%   Input signal   -->+-----Quantization------|-------                 %");  
disp("%                     ^-                      V                        %");
disp("%                     |---------------------->+                        %");
disp("%                 out |<----Predictor<--------| inp                    %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");
 pause(5)
disp("\n ");  

%se generan los coeficientes �ptimos del predictor
[partition2,initcodebook]=lloyds(Y1,len);
[predictor,codebook,partition] = dpcmopt(Y1,ord,initcodebook); 
%se genera el error cuantificado
[encodedx,ind] = enco(Y1,codebook,partition,predictor); 
[decodedx, erroquan] = deco(encodedx,codebook,predictor); 
 
%filtro pasa bajo, se recupera la se�al PCM 
fc=1/2;
[b,a]=butter(12,fc);
Yy=filter(b,a,squan);
%filtro pasa bajo, se  recupera la se�al DPCM 
decodedx1=filter(b,a,decodedx);
%DEP PCM Y DPCM
deppcm=fftshift((abs(fft(squan))).^2)/(length(squan));
depdpcm=fftshift((abs(fft(ind))).^2)/(length(ind));
e=Y1-squan;%error de cuantificaci�n


%DEP DE LAS SE�ALES RECUPERADAS
deppcmr=fftshift((abs(fft(Yy))).^2)/(length(Yy));
depdpcmr=fftshift((abs(fft(decodedx1))).^2)/(length(decodedx1));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%GRAFICAS Y RELACIONES DE POTENCIA; DISTORCION%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%PCM%%%%%%%%%%

figure (3)
subplot (2,1,1)
plot(t1,squan)
legend ('Senal de voz PCM');
xlabel('segundos');
subplot (2,1,2)
plot(t1, Yy)
legend ('Senal de voz Recuperada');
xlabel('segundos');

figure (4) 
plot(t1, e)
legend ('Error cuantificacion PCM');
xlabel('segundos');

px=mean(Y.*Y);%potencia de se�al original fs 44100
py11=mean(squan.*squan);%potencia de la se�al cuantificada PCM
pxc=mean(Y1.*Y1);%potencia de la se�al muestreada
ps=mean(Yy.*Yy); %potencia de la se�al recuperada con el filtro 
snr11=ps/px; % Relaci�n de potencia:  potencia de la se�al recuperda / potencia de la se�al original 44100
distor11 = sum((Y1-squan).^2)/length(Y1); % Potencia del error de cuantificaci�n PCM
snqpcm=pxc/distor11; % relaci�n se�al a ruido de cuantificaci�n PCM 

%%%%%%%%DPCM%%%%%%%%%%
figure (5)
subplot (2,1,1)
plot(t1,ind)
legend ('Senal DPCM');
xlabel('segundos');
subplot (2,1,2)
plot(t1,decodedx1)
legend ('Senal de voz Recuperda DPCM');
xlabel('segundos');

distor = sum((Y1-decodedx).^2)/length(Y1); % Potencia del error de cuantificaci�n 
py=mean(decodedx1.*decodedx1);%Potencia de la se�al Recuperada
snr=py/px;%Relaci�n de potencia:  potencia de la se�al recuperda / potencia de la se�al original 44100
snqdpcm=pxc/distor; %relaci�n se�al a ruido de cuantificaci�n DPCM 

figure (6)
subplot (2,1,1)
plot(f1,deppcm)
legend ('DEP Senal PCM');
subplot (2,1,2)
plot(f1,depdpcm)
legend ('DEP Senal DPCM');
xlabel('Hz');

figure(7)
subplot (2,1,1)
plot(f1,deppcmr)
legend ('DEP Senal  Recuperada PCM');
subplot (2,1,2)
plot(f1,depdpcmr)
legend ('DEP Senal Recueperda DPCM');
xlabel('Hz');

figure(8)
hist(e,20);
title ('Estimado de la Funcion de Densidad de Probabilidades del Error de Cuantificacion PCM');
printf(" La Potencia de error de cuantificaci�n  en PCM es:%g \n",distor11);
printf(" La Potencia de error de cuantificaci�n DPCM es:%g \n",distor);
printf(" La relaci�n se�al a ruido  de cuantificaci�n PCM  es :%g \n",snqpcm);
printf(" La relaci�n se�al a ruido  de cuantificaci�n DPCM es :%g \n",snqdpcm);
printf(" La relaci�n se�al a ruido  de PCM es :%g \n",snr11);
printf(" La relaci�n se�al a ruido  de DPCM es :%g \n",snr);



































