%#Programa 1  PCM/DPCM (Muestreo y Cuantificaci�n)
clc% Limpiar pantalla 
clear all 
close all
disp("                Programa 1 Introduccion a:              "); 
disp("            PCM: Modulaci�n por impulsos modificados \n "); 
disp("            DPCM: Differential Pulse Code Modulation \n "); 


disp("%---------------------------------------------------------------------------------%");
disp("% PCM es una t�cnica de modulaci�n por codificaci�n digital usada                 %");
disp("% para la transmisi�n digital de informaci�n.                                     %");
disp("% Es una codificaci�n de fuente ya que toma una se�al anal�gica para              %");
disp("% luego representarla de manera digital.                                          %");
disp("% La tasa de muestreo, es el n�mero de muestras que se toman por segundo          %");
disp("% Nivel de Cuantificaci�n: Rango de valores digitales que puede tomar una muestra %");
disp("%---------------------------------------------------------------------------------%");
pause(10);
disp("%----------------------------------------------------------------------%");
disp("%Para la simulaci�n se utilizar� una se�al de voz                      %");
disp("%femenina previamente grabada a una frecuencia de muestreo FS=44100Hz  %");
disp("%Se realizar� un submuestreo a frecuencias de fs=8820 y fs=1102        %");
disp("%Usted podra ingresar el n�mero de niveles de cuantificaci�n           %");
disp("%El orden del predictor utilizado en DPCM es ord= 2                    %");
disp("%----------------------------------------------------------------------%");	
pause(10); 

%--------------- Preguntas Iniciales-----------------------------------
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%  Antes de realizar la simulaci�n usted debe responder     %");
disp("%          las siguientes preguntas de selecci�n:           %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
pause(3)
disp("\n "); 
disp("%-----------------------------------------------------------------------------------%");
disp("%  1.Se puede recuperar la se�al anal�gica a partir de su                           %");
disp("%  discretizaci�n en tiempo si:                                                     %");
disp("%    (a)La frecuencia de muestreo es = al ancho de banda de la se�al                %");                        
disp("%    (b)La frecuencia de muestreo es < que 2 veces el ancho de banda de la se�al    %");                                 
disp("%    (c)La frecuencia de muestreo es >= que 2 veces el ancho de banda de la se�al   %");
disp("%-----------------------------------------------------------------------------------%");	
input(" ");
r1=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)
tr=0;
if r1=='c'
	tr=tr+1;
else
	disp("Respuesta Incorrecta. Para poder recuperar la se�al original es necesario que la frecuencia de "); 
	disp(" muestreo sea >= 2 veces el ancho de banda de la se�al, ya que si esto no se cumple los espectros de");
	disp("la se�al muestreada se solapar�n. A este efecto se le conoce como  aliasing  ");
	pause(7)
endif

disp("\n "); 
disp("%-----------------------------------------------------------------------%");
disp("%  2. El proceso de cuantificaci�n consite en:                          %");
disp("%    (a)Discretizar la se�al en tiempo                                  %");                        
disp("%    (b)Discretizar la se�al en amplitud                                %");                                 
disp("%    (c)Discretizar la se�al en amplitud y tiempo                       %");
disp("%-----------------------------------------------------------------------%");	
r2=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)

if r2=='b'
	tr=tr+1;
else
	disp("Respuesta Incorrecta. La cuantificaci�n discretiza la se�al en amplitud, asiginando"); 
	disp(" un valor discreto de amplitud a cada una de las muestras  ");
		pause(7)
endif

disp("\n "); 
disp("%-----------------------------------------------------------------------%");
disp("%  3. la cuantificaci�n Uniforme es aquella donde                       %");
disp("%    (a)La distancia entre los niveles es constante                     %");                        
disp("%    (b)Se le asigna un n�mero mayor de niveles a las zonas             %");
disp("%       de voltaje de la se�al original m�s frecuentes.                 %");
disp("%    (c)Se le asigna un n�mero mayor de niveles a las zonas             %");
disp("%       de voltaje de la se�al original menos frecuentes.               %");
disp("%-----------------------------------------------------------------------%");	
r3=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)

if r3=='a'
	tr=tr+1;
else
	disp("Respuesta Incorrecta. En la  cuantificacion uniforme "); 
	disp("la distancia entre los niveles es constante"); 
	pause(5)
endif

disp("\n "); 
disp("%-----------------------------------------------------------------------%");
disp("%  4.El ancho de banda de una se�al PCM sera:                           %");
disp("%    (a)Mayor que el ancho de banda de la se�al anal�gica               %");                        
disp("%    (b)Menor que el ancho de banda de la se�al anal�gica               %");
disp("%    (c)Igual que el ancho de banda de la se�al anal�gica               %");
disp("%-----------------------------------------------------------------------%");	
r4=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)

if r4=='a'
	tr=tr+1;
else
	disp("Respuesta Incorrecta, El ancho de banda de la se�al PCM es mayor que el de la se�al original "); 
	pause(5)
endif


%---------------------------------------------------------------------------------
[Y1,FS, BITS] = wavread('femenina1.wav');
%abre un archivo de audio y guarda las muestras en el vector Y1 , FS frecuencia del mensaje
Y=Y1(:,1)';
Y=Y(31000:62000);%se eliminan los silencios  iniciales y finales de la se�al de voz
%----------------------------------------------------
%Y=Y';
m=mean (Y);%obtiene el promedio de Y
Y=Y-m; %elimina el nivel DC de la se�al
l=length(Y);% retorna la longitud de  Y 
Y=Y(1 : (l));
t=(0:(l)-1)/FS;	  %se genera el vector de tiempo asociado a Y
f=linspace(-FS/2,FS/2,l); %se genera el vector frecuencia asociado a FFT(Y)

%-------------------------------------------------------
%normalizaci�n de la se�al (entre -1 y 1) para facilitar su cuantificaci�n
disp("La se�al se normaliza (-1,1) para facilitar cuantificaci�n "); 
pause(2)
y2max=abs(max(Y));
y2min=abs(min(Y));

if y2max>=y2min
    voltnorm=y2max;
elseif y2min>y2max
    voltnorm=y2min;
end 

Y=Y/voltnorm;
depy=fftshift((abs(fft(Y))).^2)/l;  %DEP de Y (DEP de se�al original)
%----------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%MUESTREO%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%se realiza el muestreo a la frecuencia de 8820 Hz
	Y8k=downsample(Y,5);
	l8k=length(Y8k);
	fs8k=8820;
	t8k=(0:(l8k)-1)/fs8k;	  %se genera el vector de tiempo asociado a Y8k
	f8k=linspace(-fs8k/2,fs8k/2,l8k); %se genera el vector frecuencia asociado a FFT(Y8k)
	Y8k=Y8k(1 : (l8k));
  depy8k=fftshift((abs(fft(Y8k))).^2)/l8k;  %DEP de Y8K (se�al muestreada)

%se realiza el muestreo a la frecuencia de 1102Hz

  Y1k=downsample(Y,40);
	l1k=length(Y1k);
	fs1k=1102;
	t1k=(0:(l1k)-1)/fs1k;	  %se genera el vector de tiempo asociado a Y1k
	f1k=linspace(-fs1k/2,fs1k/2,l1k); %se genera el vector frecuencia asociado a FFT(Y1k)
	Y1k=Y1k(1 : (l1k));
  depy1k=fftshift((abs(fft(Y1k))).^2)/l1k;  %DEP de Y1k (se�al muestreada)

%----------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Se�al original y  muestreada en tiempo %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
subplot (3,1,1)
plot(t,Y)		% Grafica la se�al original
legend ('Senal de voz Original');

subplot (3,1,2)
plot(t8k,Y8k)		% Grafica la se�al muestreada (8k)
legend ('Senal de voz Muestreada a fs 8820');

subplot (3,1,3)
plot(t1k,Y1k)		% Grafica la se�al muestreada(1k)
legend ('Senal de voz Muestreada a fs 1102');
xlabel('segundos');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DEP Se�al original y  muestreada %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	figure (2)
	subplot (3,1,1)
	plot(f,depy)
	legend ('DEP Senal Original');
 	%	figure (3)
	subplot (3,1,2)
	plot(f8k,depy8k);
	legend ('DEP Senal Muestreada a fs 8820');
 
	%	figure (4)
	subplot (3,1,3)
	plot(f1k,depy1k);
	legend ('DEP Senal Muestreada a fs 1102');
  xlabel('Frecuencia Hz');

%-------------------------------------------------
%CUANTIFICACION
disp("%-------------------------------------------------------------------------%");
disp("%  A continuaci�n se realizar� la cuantificaci�n para una de las se�ales  %");
disp("%  muestreadas . usted debe seleccionar si sera la de fs=8820 o fs=1102   %");  
disp("% El orden del predictor utilizado en DPCM es ord= 2                      %");
disp("%-------------------------------------------------------------------------%");	
 pause(2)
 disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
 disp("%      Se�al a cuantificar:                  %"); 
 disp("% (1)fs=8820 Hz                              %");
 disp("% (2)fs=1102 Hz                              %");
 disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	
 s=input("ingrese la opci�n: ");%el usuario selcciona nivel de cuantificaci�n
 pause(2)
 disp("\n ");

if s== 1 % selecci�n de frecuencia de muestreo 
	 Y1=Y8k;
	 t1=t8k; 
	 fs1=fs8k;
	 f1=f8k;
else
	Y1=Y1k;
	t1=t1k;
	fs1=fs1k;
	f1=f1k;
endif


 disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
 disp("%             Cuantificaci�n                 %"); 
 disp("% Seleccione los niveles de Cuantificaci�n:  %");
 disp("% (1)2                                       %");
 disp("% (2)4                                       %");
 disp("% (3)8                                       %");
 disp("% (4)16                                      %");
 disp("% (5)32                                      %");
 disp("% (6)64                                      %");                                 
 disp("% (7)128                                     %");
 disp("% (8)256                                     %");
 disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	
 bit=input("ingrese la opci�n: ");%el usuario selcciona nivel de cuantificaci�n
 pause(2)
 disp("\n "); 

len=(2^bit);%niveles de cuantificaci�n
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%   El nivel de cuantificaci�n seleccionado es para PCM como para DPCM %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
 pause(2)

%%%%%%%%%%%CUANTIFICACION PCM%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 no_qs = len;
 in = Y1;
 qstep = 2/no_qs;

 for ii = 1:no_qs
    range(ii) = -1 + (ii-1)*qstep;
 end
 out = zeros(size(in));
 for ii = no_qs:(-1):1
     out = out + (in>=range(ii));
 end
 out = out - 1;
 out = (out) * qstep + (-1 + qstep/2);
 squan=out;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%DPCM%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp("\n "); 
disp("Estructura  de DPCM : \n")
disp("\n "); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%                       e                   quant                      %");
disp("%   Input signal   -->+-----Quantization------|-------                 %");  
disp("%                     ^-                      V                        %");
disp("%                     |---------------------->+                        %");
disp("%                 out |<----Predictor<--------| inp                    %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");
 pause(2)
disp("\n ");  
ord=1;
%se generan los coeficientes �ptimos del predictor
[partition2,initcodebook]=lloyds(Y1,len); 
[predictor,codebook,partition] = dpcmopt(Y1,ord,initcodebook); 
%se genera el error cuantificado
[encodedx,ind] = enco(Y1,codebook,partition,predictor); 
[decodedx, erroquan] = deco(encodedx,codebook,predictor); 

%filtro pasa bajo, se recupera la senal PCM 
fc=1/2;
[b,a]=butter(12,fc);
Yy=filter(b,a,Y1);
%DEP PCM Y DPCM
deppcm=fftshift((abs(fft(squan))).^2)/(length(squan));
depdpcm=fftshift((abs(fft(ind))).^2)/(length(ind));
e=Y1-squan;%error de cuantificaci�n

%%%%%%%%%%%%GRAFICAS Y RELACIONES DE POTENCIA; DISTORCION%%%%%%%%%%%%%%%%

%%%%%PCM%%%%%%%%%%

figure (3)
subplot (2,1,1)
plot(t1,squan)
legend ('Senal de voz PCM');
xlabel('segundos');
subplot (2,1,2)
plot(t1, Yy)
legend ('Senal de voz Recuperada');
xlabel('segundos');

figure (4) 
plot(t1, e)
legend ('Error cuantificacion PCM');
xlabel('segundos');

px=mean(Y.*Y);%potencia de se�al original fs 44100
py11=mean(squan.*squan);%potencia de la se�al cuantificada PCM
pxc=mean(Y1.*Y1);%potencia de la se�al muestreada
ps=mean(Yy.*Yy); %potencia de la se�al recuperada con el filtro 
snr11=ps/px; % relaci�n de potencia:  potencia de la se�al recuperda / potencia de la se�al original 44100
distor11 = sum((Y1-squan).^2)/length(Y1); % potencia del error de cuantificaci�n PCM
snqpcm=pxc/distor11; % relaci�n se�al a ruido de cuantificaci�n PCM 

%%%%%%%%DPCM%%%%%%%%%%
figure (5)
subplot (2,1,1)
plot(t1,ind)
legend ('Senal DPCM');
xlabel('segundos');
subplot (2,1,2)
plot(t1,decodedx)
legend ('Senal de voz Recuperda DPCM');
xlabel('segundos');

distor = sum((Y1-decodedx).^2)/length(Y1); % Potencia del error de cuantificaci�n 
py=mean(decodedx.*decodedx);%Potencia de la se�al Recuperada
snr=py/px;%Relaci�n de potencia: potencia de la se�al recuperda / potencia de la se�al original 44100
snqdpcm=pxc/distor; %relaci�n se�al a ruido de cuantificaci�n DPCM 

figure (6)
subplot (2,1,1)
plot(f1,deppcm)
legend ('DEP Senal PCM');
subplot (2,1,2)
plot(f1,depdpcm)
legend ('DEP Senal DPCM');
xlabel('Hz');


printf(" La Potencia de error de cuantificaci�n  en PCM es:%g \n",distor11);
printf(" La Potencia de error de cuantificaci�n DPCM es:%g \n",distor);
printf(" La relaci�n se�al a ruido  de cuantificaci�n PCM  es :%g \n",snqpcm);
printf(" La relaci�n se�al a ruido  de cuantificaci�n DPCM es :%g \n",snqdpcm);
printf(" La relaci�n se�al a ruido  de PCM es :%g \n",snr11);
printf(" La relaci�n se�al a ruido  de DPCM es :%g \n",snr);


pause(20)

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%                     Autoevaluaci�n          	                        %"); 
disp("%                                                                       %");  
disp("% A partir de los resultados obtenidos se le realizar�n                 %");
disp("% una serie de preguntas y sugerencias para comprobar su comprensi�n    %");
disp("% sobre los resultados arrojados en la simulaci�n.                      %"); 
disp("%                                                                       %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");

pause(4)
disp("\n "); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("% Verifique que la Potencia de error de cuantificaci�n PCM  coincide aproximadamente con : %");
disp("% 1/(3*Q^2) , donde Q coincide con los niveles de cauntificaci�n utilizados                %");    
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
pause(4)

disp("\n "); 
disp("%---------------------------------------------------------------------------%");
disp("%  5.El ruido en la se�al recuperada PCM, en esta simulaci�n, es debido a:  %");
disp("%    (a)Al ruido del canal                                                  %");                        
disp("%    (b)Al ruido de cuantizaci�n                                            %");
disp("%    (c)Las 2 anteriores                                                    %");
disp("%---------------------------------------------------------------------------%");	
r5=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)

if r5=='b'
	tr=tr+1;
else
	disp("Respuesta Incorrecta. En esta se�al simulada el ruido que afecta es el de cuantizaci�n"); 
	pause(3)  
endif

disp("\n "); 
disp("%---------------------------------------------------------------------------%");
disp("%  6.La potencia del error de cuantificaci�n en DPCM diminuye:              %");
disp("% (a)Si la correlaci�n entre muestras consecutivas es alta                  %");
disp("% (b)Si la correlaci�n entre muestras consecutivas es baja                  %");
disp("% (c)No depende de la  correlaci�n entre muestras consecutivas              %");
disp("%---------------------------------------------------------------------------%");
r6=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)

if r6=='a'
	tr=tr+1;
else
	disp("Respuesta Incorrecta. La potencia disminuye si la correlaci�n entre muestras consecutivas es alta"); 
	pause(3)
endif



if tr>=4 
	disp("  Su total de respuestas correctas fue superior a 4, usted puede ejecutar el modulo de PCM/DPCM");
else
	disp(" Su total de respuesta correctas fue inferior a 4.  Se recomienda repasar los contenidos de este modulo");
	endif
