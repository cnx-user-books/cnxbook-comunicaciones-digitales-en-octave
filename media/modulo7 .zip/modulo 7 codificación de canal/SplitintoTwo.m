function out=SplitintoTwo(intval)
%splits an integer value into two 4-bit binary numbers
    out=zeros(2,4);
    for i=8:-1:1
        if i>4
            if (intval >= 2^(i-1))
                out(1,8-i+1)=1;
                intval=intval-2^(i-1);
            end
         else
             if (intval >= 2^(i-1))
                  out(2,4-i+1)=1;
                  intval=intval-2^(i-1);
             end
        end
    end
end
