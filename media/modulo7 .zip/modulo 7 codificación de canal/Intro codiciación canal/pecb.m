function [EN,BERt0,BERt,BERt2,BERpractico,BERpractico1bit] = pecb(fs2,senalHamming,codificada,sc,PN,n,l,K)
%funci�n donde se genera la probabilidad de error te�rica,
%pr�ctica y pr�ctica con un bit corregido.


y=senalHamming;% se�al codificada Hamming
RUIDO=PN;%potencia de ruido
fs=fs2;%puntos de la base2
pp=fs2;
N=n;%k+m, se agregan 3 bits redundantes
L=l;%n�mero de filas de k bits input
code=codificada;% se�al codificada hammming
k1=K;%n�mero del bits de mensaje
mb=sc;%se�al sin codificar

fs1=1000; %frecuencia de muestreo


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%% Para la probabilidad de error %%%%%%%%%%
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
noise=randn(size(y));
noise0=sqrt(1*RUIDO)*noise;
noise1=sqrt(1.17*RUIDO)*noise;
noise2=sqrt(1.25*RUIDO)*noise;
noise3=sqrt(1.41*RUIDO)*noise;
noise4=sqrt(1.58*RUIDO)*noise;
noise5=sqrt(1.77*RUIDO)*noise;
noise6=sqrt(2*RUIDO)*noise;
noise7=sqrt(2.2*RUIDO)*noise;
noise8=sqrt(2.52*RUIDO)*noise; 
%se�ales m�s ruido


y0=y+noise0;
y1=y+noise1;
y2=y+noise2;
y3=y+noise3;
y4=y+noise4;
y5=y+noise5;
y6=y+noise6;
y7=y+noise7;
y8=y+noise8;


 

 

# %%%%%%% Detecci�n de las se�ales%%%%%%%%%%%%%%%%%


  
for k=1:L*N
   

		det1(k)=pp*(mean(y0(1+(k-1)*fs:k*fs))); 


    if det1(k)>0
        hammingRx0(k)=1;
    else
        hammingRx0(k)=0;
		    end

	


%y1
		det11(k)=pp*(mean(y1(1+(k-1)*fs:k*fs))); 


    if det11(k)>0
        hammingRx1(k)=1;
    else
        hammingRx1(k)=0;
		end


	
	
	%y2
		det12(k)=pp*(mean(y2(1+(k-1)*fs:k*fs))); 


    if det12(k)>0
        hammingRx2(k)=1;
    else
        hammingRx2(k)=0;
		    end




%y3
		det13(k)=pp*(mean(y3(1+(k-1)*fs:k*fs))); 
   

    if det13(k)>0
        hammingRx3(k)=1;
    else
        hammingRx3(k)=0;
		    end


	
	%y4
		det14(k)=pp*(mean(y4(1+(k-1)*fs:k*fs))); 


    if det14(k)>0
        hammingRx4(k)=1;
    else
        hammingRx4(k)=0;
		    end

	
	
	
	%y5
		det15(k)=pp*(mean(y5(1+(k-1)*fs:k*fs))); 


    if det15(k)>0
        hammingRx5(k)=1;
    else
        hammingRx5(k)=0;
		    end

	
	
	%y6
		det16(k)=pp*(mean(y6(1+(k-1)*fs:k*fs))); 


    if det16(k)>0
        hammingRx6(k)=1;
    else
        hammingRx6(k)=0;
		    end


	
	%y7
		det17(k)=pp*(mean(y7(1+(k-1)*fs:k*fs))); 


    if det17(k)>0
        hammingRx7(k)=1;
    else
        hammingRx7(k)=0;
		    end




	%y8
		det18(k)=pp*(mean(y8(1+(k-1)*fs:k*fs))); 


    if det18(k)>0
        hammingRx8(k)=1;
    else
        hammingRx8(k)=0;
		    end



end

%Pe se�al y0
	h0=reshape(hammingRx0,N,L);% devuelve una matriz NxL de los elementos tomados de hammingrx
	h0=h0';  
	%bitter compara la se�al hamming recuperada con la enviada 
	[n0,pe0] = biterr(h0,code);

	%se decodifica la se�al recibida 
	msgbirecibido0= decode(h0,N,k1,'hamming');
	[n01,pe01] = biterr(msgbirecibido0,mb);

%Pe se�al y1
	h1=reshape(hammingRx1,N,L);% devuelve una matriz NxL de los elementos tomados de hammingrx
	h1=h1';  
	%bitter compara la se�al hamming recuperada con la enviada 
	[n1,pe1] = biterr(h1,code);

	%se decodifica la se�al recibida 
	msgbirecibido1= decode(h1,N,k1,'hamming');
	[n11,pe11] = biterr(msgbirecibido1,mb);

%Pe se�al y2
	h2=reshape(hammingRx2,N,L);% devuelve una matriz NxL de los elementos tomados de hammingrx
	h2=h2';  
	%bitter compara la se�al hamming recuperada con la enviada 
	[n2,pe2] = biterr(h2,code);

	%se decodifica la se�al recibida 
	msgbirecibido2= decode(h2,N,k1,'hamming');
	[n21,pe21] = biterr(msgbirecibido2,mb);

%Pe se�al y3
	h3=reshape(hammingRx3,N,L);% devuelve una matriz NxL de los elementos tomados de hammingrx
	h3=h3';  
	%bitter compara la se�al hamming recuperada con la enviada 
	[n3,pe3] = biterr(h3,code);

	%se decodifica la se�al recibida 
	msgbirecibido3= decode(h3,N,k1,'hamming');
	[n31,pe31] = biterr(msgbirecibido3,mb);
	
	
	
	
%Pe se�al y4	

	h4=reshape(hammingRx4,N,L);% devuelve una matriz NxL de los elementos tomados de hammingrx
	h4=h4';  
	%bitter compara la se�al hamming recuperada con la enviada 
	[n4,pe4] = biterr(h4,code);

	%se decodifica la se�al recibida 
	msgbirecibido4= decode(h4,N,k1,'hamming');
	[n41,pe41] = biterr(msgbirecibido4,mb);

%Pe se�al y5	
h5=reshape(hammingRx5,N,L);% devuelve una matriz NxL de los elementos tomados de hammingrx
	h5=h5';  
	%bitter compara la se�al hamming recuperada con la enviada 
	[n5,pe5] = biterr(h5,code);

	%se decodifica la se�al recibida 
	msgbirecibido5= decode(h5,N,k1,'hamming');
	[n51,pe51] = biterr(msgbirecibido5,mb);

%Pe se�al y6	
	h6=reshape(hammingRx6,N,L);% devuelve una matriz NxL de los elementos tomados de hammingrx
	h6=h6';  
	%bitter compara la se�al hamming recuperada con la enviada 
	[n6,pe6] = biterr(h6,code);

	%se decodifica la se�al recibida 
	msgbirecibido6= decode(h6,N,k1,'hamming');
	[n61,pe61] = biterr(msgbirecibido6,mb);

%Pe se�al y7	

	h7=reshape(hammingRx7,N,L);% devuelve una matriz NxL de los elementos tomados de hammingrx
	h7=h7';  
	%bitter compara la se�al hamming recuperada con la enviada 
	[n7,pe7] = biterr(h7,code);

	%se decodifica la se�al recibida 
	msgbirecibido7= decode(h7,N,k1,'hamming');
	[n71,pe71] = biterr(msgbirecibido7,mb);

%Pe se�al y8	
	h8=reshape(hammingRx8,N,L);% devuelve una matriz NxL de los elementos tomados de hammingrx
	h8=h8';  
	%bitter compara la se�al hamming recuperada con la enviada 
	[n8,pe8] = biterr(h8,code);

	%se decodifica la se�al recibida 
	msgbirecibido8= decode(h8,N,k1,'hamming');
	[n81,pe81] = biterr(msgbirecibido8,mb);

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 FS=1000;%Frecuencia de muestreo
 eta0=mean(noise0.^2)*2/FS; 
 eta1=mean(noise1.^2)*2/FS;
 eta2=mean(noise2.^2)*2/FS;
 eta3=mean(noise3.^2)*2/FS;
 eta4=mean(noise4.^2)*2/FS;
 eta5=mean(noise5.^2)*2/FS;
 eta6=mean(noise6.^2)*2/FS;
 eta7=mean(noise7.^2)*2/FS;
 eta8=mean(noise8.^2)*2/FS;
 etas=[eta8 eta7 eta6 eta5 eta4 eta3 eta2 eta1 eta0];
P=mean(y.*y);
EnerProm=P*0.1; 
 fs=1000;
 EN0=10*log10(EnerProm/eta0);
 EN1=10*log10(EnerProm/eta1);
 EN2=10*log10(EnerProm/eta2);
 EN3=10*log10(EnerProm/eta3);
 EN4=10*log10(EnerProm/eta4);
 EN5=10*log10(EnerProm/eta5); 
 EN6=10*log10(EnerProm/eta6);
 EN7=10*log10(EnerProm/eta7);
 EN8=10*log10(EnerProm/eta8);
EentreEta=EnerProm./(etas);

EN=[EN8 EN7 EN6 EN5 EN4 EN3 EN2 EN1 EN0];
	 BERt0 = qfunc(sqrt(2*EnerProm./(etas)));
	 BERt = qfunc(sqrt((K/N)*2*EnerProm./(etas)));
	 BERt2=6*BERt.*BERt;
	 BERpractico= [pe8 pe7 pe6 pe5 pe4 pe3 pe2 pe1 pe0];
	 BERpractico1bit= [pe81 pe71 pe61 pe51 pe41 pe31 pe21 pe11 pe01];
end





