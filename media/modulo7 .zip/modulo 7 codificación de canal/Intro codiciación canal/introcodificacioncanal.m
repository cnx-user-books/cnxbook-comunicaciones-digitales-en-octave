#programa 10 codificaci�n de canal

clear all
close all 
disp("           Programa 10: Codificaci�n de Canal (C�digos de Bloque)         \n "); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("% Se simula un sistema de codificaci�n de canal (Codificaci�n por bloques)                    %")
disp("% Hamming(7,4) y Hamming(15,11)                                                               %")
disp("% La se�al a transmitir es una se�al NRZ,la cual pasa por un canal AWGN y un receptor �ptimo  %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
disp("\n "); 
pause(3)
%--------------- Preguntas Iniciales-----------------------------------
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%  Antes de realizar la simulaci�n usted debe responder     %");
disp("%          las siguientes preguntas de selecci�n:           %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
pause(2)
disp("\n "); 



disp("%-------------------------------------------------------------%");
disp("%  1.La codidificaci�n de Canal  para el control de           %");
disp("%  errores se encarga de:                                     %");
disp("%    (a)Optimizar la Potencia de Transmisi�n                  %"); 
disp("%    (b)Mejorar la velocidad de transmisi�n                   %");  
disp("%    (c)Mejorar la fiabilidad                                 %");  
disp("%-------------------------------------------------------------%");	
input(" ");
r1=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)
tr=0;
if r1=='c'
	tr=tr+1;
else
	disp("Respuesta Incorrecta. La codificaci�n de canal mejora la fiabilidad, ");
	disp("adicionanado d�gitos extras al mensaje a transmitir, los cuales hacen "); 
	disp("posible la detecci�n y correcci�n de errores en el bloque de recepci�n. del mensaje.");
	pause(4)
endif

disp("\n "); 
disp("%-----------------------------------------------------------------------%");
disp("%  2.Si al combinar dos palabras c�digos se genera una tercer c�digo    %");
disp("%    v�lido, se dice que la codificaci�n es:                            %");
disp("%    (a)Convolucional                                                   %"); 
disp("%    (b)Lineal                                                          %"); 
disp("%    (c)Sistem�tica                                                     %"); 
disp("%-----------------------------------------------------------------------%");	
r2=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)
if r2=='b'
	tr=tr+1;
else
	disp("Respuesta Incorrecta. Esto define una caracter�stica de los c�digos de bloques, que es la linealidad ");
	pause(3)
endif
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% Simulaci�n %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%                     Simulaci�n                          %"); 
disp("%                                                         %");  
disp("%  A  continuaci�n se  realiza la simulaci�n de una se�al %");
disp("%  codificada  H(7,4)  y  una se�al  H(15,11)             %");
disp("%  Para relizar el c�lculo de la probabilidad de error(Pe)%"); 
disp("%  se generan 8 se�ales con diferentes potencias de ruido %"); 
disp("%  partiendo de una potencia PN=12W                       %"); 
disp("%                                                         %"); 
disp("%  Se presentan las gr�ficas de Pe para H(7,4) y H(15,11) %"); 
disp("%   con las sigueintes curvas :                           %"); 
disp("% Probabilidad de error Te�rica NRZp                      %");
disp("% Pc:Pe codificado sin corregir errores te�rica y pr�ctica%");
disp("% Pdc:Pe detectado y corregido  te�rica y pr�ctica        %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("\n ");
pause(8)
disp("%-------------------------------------------------------------%");
disp("%  La frecuencia de muestreo  se fija en 1000 Hz              %"); 
disp("%  El tiempo de bit se fija en 100ms                          %"); 
disp("%-------------------------------------------------------------%");
disp("\n ");
pause(2)


PN=12;
[EN,BERt0,BERt24,BERpractico1bit4] = hammingNRZp74;
[EN,BERt0,BERt215,BERpractico1bit15] = hammingNRZ1511;


figure(7)
semilogy(EN,BERt0,'c');
hold on
semilogy(EN,BERt24,'r');
hold on
 semilogy(EN,BERt215,'b');
 hold on 
 semilogy(EN,BERpractico1bit4,'m.-');
 hold on
 semilogy(EN,BERpractico1bit15 ,'g.-');
  hold on
	title('Pe vs E/n modulacion FSK Hamming(15,11)')
	legend('teoricoNRZp', 'Teorico1=Pdc (7,4)', 'Teorico2=Pdc (15,11)', 'practico 1bit corregido H(7,4)','practico 1bit corregido H(15,11)');
	xlabel('E/N, dB')
	ylabel('Tasa de Error por bit')


%--------------------Preguntas de autoevaluaci�n--------------------------------
pause(10)

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%                     Autoevaluaci�n          	                        %"); 
disp("%                                                                       %");  
disp("% A partir de los resultados obtenidos en las gr�ficas se le realizar�n %");
disp("% una serie de preguntas para comprobar su comprensi�n sobre los        %");
disp("% resultados arrojados en la simulaci�n.                                %"); 
disp("%                                                                       %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
pause(2)
disp("\n "); 
disp("%-----------------------------------------------------------------------%");
disp("%  3.  Hamming (7.4) puede:                                             %");
disp("%    (a)corregir errores de un solo bit                                 %"); 
disp("%    (b)Detectar  errores en un solo bit                                %"); 
disp("%    (c)Corregir errores de un solo bit y detectar errores en 2 bits    %"); 
disp("%-----------------------------------------------------------------------%");	
r3=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)
if r3=='c'
	tr=tr+1;
else 
	disp("Respuesta Incorrecta.Hamming (7.4) corrige errores de un solo bit y detecta errores en 2 bits  ");
	pause(2)
endif
 

disp("\n "); 
disp("%-----------------------------------------------------------------------%");
disp("%  4. Al observar la DEP de la se�al original NRZp y las codificadas    %");
disp("%  H(7,4) y H(15,11) se puede concluir que:                             %");
disp("%    (a)No se afecta el ancho de banda                                  %"); 
disp("%    (b)El ancho de banda es menor para las se�ales codificadas         %"); 
disp("%    (c)El ancho de banda es mayor para las se�ales codificadas         %"); 
disp("%-----------------------------------------------------------------------%");	
r4=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)
if r4=='c'
	tr=tr+1;
else 
	disp("Respuesta Incorrecta. Al codificar con Hamming se aumenta el ancho de banda de la se�al a transmitir  ");
	pause(2)
endif
 
disp("\n "); 
disp("%-----------------------------------------------------------------------%");
disp("%  5. De la gr�fica 7 de Pe, al comparar los valores de Pe te�ricos     %");
disp("%  se observa  mayor fortaleza frente al ruido en:                      %");
disp("%    (a)Hammming(7,4)                                                   %"); 
disp("%    (b)Hammming(15,11)                                                 %"); 
disp("%    (c)NRZp                                                            %"); 
disp("%-----------------------------------------------------------------------%");	
r5=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(2)
if r5=='b'
	tr=tr+1;
else 
	disp("Respuesta Incorrecta. De los tres sistemas, bajo las mismas condiciones de potencia de ruido en el canal el que posee menor Pe es Hamming (15,11) ");
	pause(2)
endif

if tr>=3 
	disp("  Su total de respuestas correctas fue superior a 3, usted puede ejecutar el m�dulo de Codificaci�n de Canal");
else
	disp(" Su total de respuesta correctas fue inferior a 3.  Se recomienda repasar los contenidos de este m�dulo");
	endif












