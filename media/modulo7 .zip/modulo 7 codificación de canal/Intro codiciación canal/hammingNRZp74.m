function [EN,BERt0,BERt2,BERpractico1bit] = hammingNRZp74
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all

K=4;%n�mero del bits de mensaje
N=7;%k+m, se agregan 3 bits redundantes
L=200;%n�mero de filas de k bits input
%PN=RUIDO;%potencia de ruido
PN=12;
for j=1:K
    mb(:,j)=randint(L,1,2);% se genera el mensaje que se desea enviar, secuencia de bits
    
end
%mb es la secuencia de bit 

code=encode(mb,N,K,'hamming');%se realiza la codificaci�n hammming H(N,K) 

fs=1000;%frecuencia de muestreo
fs2=57; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%% Mensaje NRZp %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mensaje=[];%vector donde se almacena el mensaje transmitido sin codificar
 for i=1:L
     for j=1:K
    switch mb(i,j)
     case 1
        for k=1:100
         mensaje=[mensaje 1];
       end
     case 0
         for k=1:100
         mensaje=[mensaje -1];
       end
     
        end     
        
    end
    
    
end

tmensaje=[0:1/fs:((K*L*100)-1)/fs];
x=mensaje;
X=fftshift(fft(x));
MX=abs(X); %DEP del mensaje
W=length(MX);
MX=MX/W;
f=-fs/2:fs/W:fs/2-fs/W; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% C�digo Hamming (7,4) a enviar%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hammingTx=[];%vector donde se almacena el mensaje transmitido codificado
for i=1:L
    for j=1:N
   switch code(i,j)
    case 1
       for k=1:57
        hammingTx=[hammingTx 1];
      end
    case 0
        for k=1:57
        hammingTx=[hammingTx -1];
       end
        end     
        
    end
end

thammingTx=[0:1/fs:((N*L*57)-1)/fs];
x=hammingTx;
X1=fftshift(fft(x));
MX1=abs(X1); %DEP
W=length(MX1);
MX1=MX1/W;
f1=-fs/2:fs/W:fs/2-fs/W; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Gr�ficas del mensaje tx%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure (1)
subplot (2,1,1)
plot( tmensaje, mensaje,'m')
legend('Mensaje Original');
xlabel('Tiempo (seg)'); ylabel('Amplitud (Volts)');
A=K*L*0.1;
axis([0 A -1.5 1.5])
subplot (2,1,2)
plot(thammingTx,hammingTx,'m')
legend('Codigo Hamming (7,4) a Enviar en tiempo');
xlabel('Tiempo (seg)'); ylabel('Amplitud (Volts)');
axis([0 A -1.5 1.5])

figure (2)
subplot (1,2,1)
plot(f,MX.*MX,'b'); % Se grafica la DEP
xlabel('Frecuencia (Hz)'); 
legend('DEP del Mensaje ');
axis([-40 40])
subplot (1,2,2)
plot(f1,MX1.*MX1,'b'); % Se grafica la DEP del mensaje codificado
xlabel('Frecuencia (Hz)');
legend('DEP Codigo Hamming (7,4)a Enviar');
axis([-40 40])


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Probabilidad de error %%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[EN,BERt0,BERt,BERt2,BERpractico,BERpractico1bit]=pecb(fs2,x,code,mb,PN,N,L,K);
 
	figure(3)
semilogy(EN,BERt0,'c');
hold on
semilogy(EN,BERt,'r');
hold on
 semilogy(EN,BERt2,'b');
 hold on 
 semilogy(EN,BERpractico,'m.-');
 hold on
 semilogy(EN,BERpractico1bit ,'g.-');
  hold on
	title('Pe vs E/n modulacion FSK Hamming(7,4)')
	legend('teoricoNRZp', 'Teorico1=Pc', 'Teorico2=Pdc', 'practico1','practico 1bit corregido');
	xlabel('E/N, dB')
	ylabel('Tasa de Error por bit')



%end



