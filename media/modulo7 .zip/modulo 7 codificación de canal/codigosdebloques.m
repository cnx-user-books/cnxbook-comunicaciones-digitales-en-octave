#programa 11 : Codificaci�n de canal por Bloques 
close all 
clear all 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%                 Programa 11 : Codificaci�n de canal por Bloques                      %");
disp("% En este programa se estudiar�n los mecanismos de generaci�n de palabras codificadas  %");
disp("%usando un m�todo de codificaci�n de canal por bloques.                                %");
disp("% Se observar� la estructura de las matrices de Generaci�n(G), Recepci�n(HT),S�ndromes %");
disp("%Se realiza una comparaci�n de los datos originales, los codificados, los contaminados %"); 
disp("% y los recuperados.                                                                   %"); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("\n ");
pause(8)
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%En la simulaci�n se utiliza una se�al de voz masculina muestreada a 8kHz.                  %");
disp("%Se simulan errores en el canal y es posible ajustar la probabilidad de                     %");
disp("%error del canal(PB) para permitir que el algoritmo trabaje en mejores o peores condiciones.%");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
pause(8)

disp("%--------------------------------------------------------------------------------------%");
disp("%--------------------------------------------------------------------------------------%");
disp(" A continuaci�n se presenta la matriz de generaci�n para un codigo H(7,4)");
disp("\n "); 

G=[[0,1,1;1,0,1;1,1,0;1,1,1],eye(4)] 
disp("%--------------------------------------------------------------------------------------%");
disp("%--------------------------------------------------------------------------------------%");
FS=8000;
senal=(wavread('uno.wav'));;%se�al de voz utilizada
l=length(senal);%longitud de la se�al de voz
t=(0:(l)-1)/FS;	 %vector tiempo

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%Codificaci�n de la se�al%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Se codifica usando G
sig=uint8(senal*255);%se�al mensaje
genmat=G;

    r=length(sig);%longitud de la se�al de voz
    out=zeros(2*r,7);% la se�al codificada es un vector rx7 donde r es la longitud del mensaje
    for i=1:r
       messages=SplitintoTwo(sig(i));%devuelve los bits del mensaje 
       out(2*i-1,:)=Mod2MatMul(messages(1,:),genmat);
       out(2*i,:)=Mod2MatMul(messages(2,:),genmat);
    end

codificada=out; %se�al codificada H(4,7), m.*G= C
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%   Rudio y detecci�n   %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp("%--------------------------------------------------------------------------------------%");
disp("%--------------------------------------------------------------------------------------%");
disp(" A continuaci�n se presenta la matriz de Recepci�n HT para un codigo H(7,4)");
disp("\n "); 
HT=[eye(3);[0,1,1;1,0,1;1,1,0;1,1,1]]%Se genera la matriz de recepci�n HT 
%cv=C.*HT %si es =0 sin errores el c�digo es valido
disp("%--------------------------------------------------------------------------------------%");
disp("%--------------------------------------------------------------------------------------%");
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%  Seleccione la Pe generada por el canal   %"); 
disp("% (1)0.001                                  %");
disp("% (2)0.1                                    %");
disp("% (3)0.3                                    %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	
input(" ");
o=input("ingrese la opci�n: ");%el usuario el tipo de modulaci�n 



if o==1
	PB=0.001;
end
if o==2
	PB=0.1;
end
if o==3
	PB=0.3;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ChannelError=rand(size(codificada))<=PB; %vector de errores de bits aleatorios
contaminada=xor(ChannelError,codificada);%se�al contaminada
sindrome=Mod2MatMul(contaminada,HT);%s�ndrome
recuperada=xor(errorpattern(sindrome),contaminada);%se�al recuperada
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tt=0;
for k=1:5000

if codificada(k,1:7)==recuperada(k,1:7)
		tt=tt+1;
		end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x=3000;%length(sindrome);
f=0;f2=0;f0=0;
et=0;%errores totales
for k=1:x;
	y=sindrome(k,1:3);
	if  sindrome(k,1)!=0 || sindrome(k,2)!=0 ||sindrome(k,3)!=0
			et=et+1;%n�mero total de errores
			if codificada(k,1:7)==recuperada(k,1:7)
				%solo hay un error y fue corregido
				s=sindrome(k,1:3);
				f=k;
			else
			
				s2=sindrome(k,1:3);
				f2=k;
				
		end
else
	s0=sindrome(k,1:3);
	f0=k;
end
end 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if f==0
	disp('No existen errores en la transmisi�n');
else
	disp("%--------------------------------------------------------------------------------------%");
	disp("%--------------------Palabra con un error ---------------------------------------------%");
	disp("%--------------------------------------------------------------------------------------%");
	disp('Fila');
	f
	disp("S�ndrome");
	s
	disp("Palabra contaminada");
	contaminada(f,1:7)
	disp("Palabra Original");
	codificada(f,1:7)
	disp("Palabra Recuperada");
	recuperada(f,1:7)
	pause(6)
  disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
 	disp("%Observe que relaci�n hay entre el s�ndrome y la matriz de recepci�n HT %");
  disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
	pause(10)
  disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
 	disp("% Al comparar el s�ndrome con la matriz HT, se puede concluir que la fila donde%");
  disp("%se ubica el s�ndrome en HT correponde al bit errado en la palabra.            %");
  disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
	pause(4)
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if f2==0
	disp('No existen palabras con m�s de 1 error');
	
else
	disp("%--------------------------------------------------------------------------------------%");
	disp("%---------------------Palabra con m�s de  2 errores------------------------------------%");
	disp("%--------------------------------------------------------------------------------------%");
	disp('Fila');
	f2
	disp("Sindrome");
	s2
	disp("Palabra contaminada");
	contaminada(f2,1:7)
	disp("Palabra Original");
	codificada(f2,1:7)
	disp("Palabra Recuperada");
	recuperada(f2,1:7)
		pause(6)
  disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
 	disp("% La fila de HT asociada al s�ndrome, no coince con los errores en la palabra. %");
  disp("% Al corregir este bit en la palabra correspondiente se genera un nuevo error. %");
  disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
	pause(6)
	
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp("%--------------------------------------------------------------------------------------%");
disp("%---------------------Palabra sin error------------------------------------------------%");
disp("%--------------------------------------------------------------------------------------%");
disp('Fila');
f0
disp("Sindrome");
s0
disp("Palabra contaminada");
contaminada(f0,1:7)
disp("Palabra Original"); 
codificada(f0,1:7)
disp("Palabra Recuperada");
recuperada(f0,1:7) 

if codificada(f0,1)!=recuperada(f0,1)|| codificada(f0,2)!=recuperada(f0,2)||codificada(f0,3)!=recuperada(f0,3)||codificada(f0,4)!=recuperada(f0,4)||codificada(f0,5)!=recuperada(f0,5)||codificada(f0,6)!=recuperada(f0,6)||codificada(f0,7)!=recuperada(f0,7)
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%  Al tener una potencia de ruido alta, la palabra contamida coincide  con  una%");
disp("% palabra c�digo, por tal motivo el sindrome es 0 aunque la palabra recuperada %");
disp("% y la original no coincidan                                                   %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp("%------------------------------------------------------------------------------------------%");
disp("%- Ustede puede escuchar  el archivo recuperado y el archivo original                     -%");
disp("%- Los archivos 'recuperada.wav' y 'original.wav' se encuentran en la carpeta de ejecuci�n-%");
disp("%- de archivos.m. La se�ales se reporducen en cualquier reproductor.                      -%");
disp("%------------------------------------------------------------------------------------------%");
%se generan dos archivos, 1 con la se�al recuparada 
%el 2do la se�al original
%los archivos deben tener la extenci�n .wav 
%pueden ser reproducidos en cualquier reproductor

recuperada4b=recuperada(:,[4,5,6,7]); %Se recuperan los 4 bits de mensaje. 
recup=FourBitToInt(recuperada4b); %Se convierte a enteros
recuperada1=double(recup);
wavwrite (recuperada1,8000,16,'recuperada')
wavwrite (senal,8000,16,'original.wav')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%