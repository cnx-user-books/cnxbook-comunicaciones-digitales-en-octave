clear all 
close all 

disp("%           Programa 9 : Interferencia Intersimbolica (ISI)               %");

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%AL tranmitir una se�al digital por un canal,el cual no solo agrega ruido,%");
disp("%sino ademas es de ancho de banda finito, se producir� dispersi�n de los  %");
disp("%pulsos transmitidos que interferir�n con los pulsos vecinos(ISI)         %");
disp("%Al receptor llegar� una se�al con ISI y ruido.                           %");
disp("%Se deben dise�ar receptores que permitan rescatar la se�al de la mejor   %");
disp("% forma y esto depende de la forma del pulso b�sico de transmisi�n p(t).  %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
pause (6)
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%Se genera una secuencia de 20 datos aleatorios                           %");
disp("% En la siguiente simulaci�n se  presentan 7 figuras en las cuales se     %");
disp("% observa la capacidad que tiene un filtro coseno alzado para combatir ISI%");
disp("%Se simula el filtraje  entre la transmisi�n y la recepci�n con filtros   %");
disp("%denominados  Raiz Cuadrada de Coseno Alzado                              %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
pause (6)
% Se usan las funciones, RCOSINE y RCOSFLT, para demostrar la capacidad que
% tiene el filtro Coseno Alzado para combatir la ISI
% Se hace uso de un transmisor y receptor que trabajan en forma conjunta
% para lograr ese prop�sito
% Se genera una secuencia aleatoria de 20 bits 
% Par�metros
Delay = 3; DataL = 20; R = .5; Fs = 8; Fd = 1; PropD = 0;
% Se generan 20 Datos aleatorios (1, -1)ubicados en 1/Fd, 2/Fd, etc..
x = randsrc(DataL, 1, [-1 1], 1245);%genera un escalar aleatorio (1 o -1) con igual probabilidad
tx = [PropD: PropD + DataL - 1] ./ Fd;
% Se grafican los datos aleatorios
stem(tx, x, 'kx');
axis([0 30 -1.6 1.6]); xlabel('Tiempo'); ylabel('Amplitud');
legend('20 Datos aleatorios');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

yp=[];
for i=1:length(x)
 yp=[yp x(i)*ones( 1,Fs)];
end
    
tp=0:1/Fs:(length(yp)-1)/Fs;
figure(2)
subplot(1,2,1)
stem(tx, x, 'kx'); 
axis([0 20 -1.6 1.6]);  xlabel('muestras'); ylabel('Amplitude');
legend('Datos Aleatorios') 
subplot(1,2,2)
plot(tp, yp, 'b-'); 
axis([0 20 -1.6 1.6]);  xlabel('segundos'); ylabel('Amplitude');
legend('Representacion NRZp(Azul)') 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RCOSFLTse usa para filtrar los datos usando RCOSINE
% Se grafican los datos aleatorios originales y los filtrados
% El filtro genera un retardo 

% Dise�o del filtro: Se le entrega la Fs (fmuestreo), 
% Fs(velocidad de tx. de los s�mbolos), el retardo (Delay)
% el tipo de filtro (fir) y el rolloff R 
[yf, tf] = rcosine(Fd, Fs, 'fir', R, Delay);

% Se filtra la se�al con el filtro dise�ado anteriormente
[yo, to] = rcosflt(x, Fd, Fs, 'filter', yf);
figure(3)
% Original
stem(tx, x, 'kx'); hold on;
% Filtrada
plot(to, yo, 'b-'); hold off;
axis([0 30 -1.6 1.6]);  xlabel('Time'); ylabel('Amplitude');
legend('Senal Filtrada con el filtro Coseno Alzado R=0.5');

% Ahora se compensar� el retardo que introdujo el filtro
% Se ve que la se�al filtrada tiene coincidencia en picos con los datos
% originales. Es mas suave y ocupar� menos ancho de banda

% Se corrije el retardo del filtro 
% el tiempo inicial ahora no es cero sino Retardo/Fd=Retardo*tsimbolo
PropD = Delay * Fd;
tx = [PropD: PropD + DataL - 1] ./ Fd;
% Se grafica la data original y la filtrada y corregida
figure(4)
stem(tx, x, 'kx'); hold on;
plot(to, yo, 'b-'); hold off;
axis([0 30 -1.6 1.6]);  xlabel('Time'); ylabel('Amplitude');
legend('Senal Filtrada con la correccion por retardo');

% Para ver el efecto del rolloff, se cambiar� de 0.5( Curva azul) a
% 0.2(Roja). 


%Se dise�a el filtro con R=0.2
[yg, tg] = rcosine(Fd, Fs, 'fir', .2, Delay);
% Se filtra la se�al original
[yo1, to1] = rcosflt(x, Fd, Fs, 'normal/fir/filter',yg);
figure(5)
stem(tx, x, 'kx'); hold on;
plot(to, yo, 'b-',to1, yo1, 'r-'); hold off;
axis([0 30 -1.6 1.6]);  xlabel('Time'); ylabel('Amplitude');
legend('Senal Filtrada con el filtro Coseno Alzado R=0.2(rojo)');


% En la pr�ctica se obtiene la forma de coseno alzado repartiendo el
% filtraje entre Tx y RX con filtros llamados Raiz Cuadrada de Coseno Alzado
% Los datos originales se filtran en el Tx con un filtro Raiz de Coseno
% Alzado y se grafican. Se coloca en los par�metros de dise�o 'fir/sqrt'


% Se dise�a
[ys, ts] = rcosine(Fd, Fs, 'fir/sqrt', R, Delay);
% Se filtra en el transmisor
[yc, tc] = rcosflt(x, Fd, Fs, 'filter', ys);
figure(6)
stem(tx, x, 'kx'); hold on;  %original
% Filtrada en el Tx
plot(tc, yc, 'm-'); hold off;
axis([0 30 -1.6 1.6]);  xlabel('Time'); ylabel('Amplitude');
legend('Senal Filtrada en el Tx con filtro Raiz de Coseno Alzado');


% La se�al transmitida(magenta) se filtra en el RX
% Usando otro filtro id�ntico al del transmisor (Raiz Coseno ALzado)
% La se�al resultante (azul) es igual a la que obtuvimos con un solo filtro
% Coseno Alzado
[ys, ts] = rcosine(Fd, Fs, 'fir/sqrt', R, Delay);
yr=conv(ys,yc);
tr=0:1/Fs:(length(yr)-1)/Fs;


# 
# %Se ajusta el Delay
tcc = tc + Delay .* Fd;  txx = tx + Delay .* Fd;
%Se grafican la original, la que usa dos filtros Raiz Coseno Alzado, 
% y la que usa en Tx un filtro Coseno ALzado
figure(7)
stem(txx, x, 'kx'); hold on;
plot(tcc, yc, 'm-');plot(tr, yr, 'b-'); hold off;
axis([0 30 -1.6 1.6]);  xlabel('Time'); ylabel('Amplitude');
legend('Original, Con Filtro Coseno Alzado y con Raiz de Coseno Alzado en Tx (magenta)') 


