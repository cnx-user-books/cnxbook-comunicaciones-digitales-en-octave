%#programa 6 C�digos de L�nea
clc% limpiar pantalla   
clear all  
close all
disp("               Programa 6: C�digos de l�nea                           \n "); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%  Se utilizar� una secuencia aleatoria de bit (100bits)        %"); 
disp("%  Usted puede fijar el tipo de codificaci�n de linea           %"); 
disp("%  a utilizar (NRZ RZ  Maschester)                              %"); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
pause(7)

%------------------------------------------------------------
%%%%%%%%%%%%%%Generaci�n de la secucencia de bits%%%%%%%%%%%%
disp(" A continuaci�n se presenta la secuencia de bits generada: ");
 pause(2)
b=randint(1,100)%Genera un vector 1x100 con bit aleatorios con igual probabilidad de ocurrencia
%para relizar una gr�fica con la secuencia de bit 
%se le asigna 10 muestras cada bit. 
nm=100;%n�mero de muestras por bit
unos=ones(1,nm);
ceros=zeros(1,nm);

y=[];
for i=1:100
        switch b(i)
            case 0
                y=[y  ceros];
            case 1
                y=[y  unos];
           
        end
                
end
l=length(y);
t=(0:(l-1))/nm;%vector de tiempo 
y1=y;


serial=b;
disp("%  El tiempo de bit se fija en 1 segundo %"); 
pause(2)
%-------------------------------------------------
%tipo de base puede ser 'NRZ', 'RZ', 'MAN', 'AMI'
fs=100;%puntos

uMan=[ones(1,fs/2)  -ones(1,fs/2)]; %base Manchester 
uNRZ=ones(1,fs);%Base no retorno a cero
uRZ= sqrt(2)*[ones(1,fs/2) zeros(1,fs/2)];%Base retorno a cero

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%             Codificaci�n de l�nea         %"); 
disp("% Seleccione el tipo de codificaci�n :      %");
disp("% (1)NRZp                                   %");
disp("% (2)RZp                                    %");
disp("% (3)Manchester                             %");
disp("% (4)NRZu                                   %");
disp("% (5)RZu                                    %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	
input(" ");
tipoBase=input("ingrese la opci�n: ");%el usuario selcciona nivel de cuantificaci�n
pause(2)
disp("\n "); 

if tipoBase==1 
     base=uNRZ;
endif
if tipoBase==2 
      base=uRZ;
endif
if tipoBase==3    
        base=uMan;         
end
if tipoBase==4    
        base=uNRZ;         
end
if tipoBase==5    
        base=uRZ;         
end


%codificaci�n de la se�al
y=[];
if tipoBase==1  ||  tipoBase==2  ||  tipoBase==3 

for i=1:length(serial)
    switch serial(i)
        case 1
            y=[y  base];
        case 0
             y=[y  -base];
    end
end

endif

if tipoBase==4 || tipoBase==5 

for i=1:length(serial)
    switch serial(i)
        case 1
            y=[y  base];
	      case 0
		        y=[y  (0*base)];
            
    end
end

endif



% y se�al codificada4
lse=length(y);
t1=(0:(lse-1))/fs;
dep1=fftshift((abs(fft(y))).^2)/lse;  %DEP de Y (se�al codificada)
f1=linspace(-fs/2,fs/2,lse);

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("% �Desea pasar la se�al codificada por un    %");
disp("% canal con ruido blanco gaussiano?          %");
disp("% (1)Si                                      %");
disp("% (2)No                                      %");
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");	
ruido=input("ingrese la opci�n: ");%el usuario selcciona nivel de cuantificaci�n
pause(5)
disp("\n "); 

if ruido==1
 pruido=input("ingrese la potencia de ruido en w: ")
 [yr]=canal(y,fs,pruido);
else
  yr=y;
endif 

if tipoBase==4 ||tipoBase==5 
	for k=1:length(serial);
				m=mean(yr(1+(k-1)*fs:k*fs));
				if m<=0.5;
        det1(k)=0;
				else
		    det1(k)=mean(yr(1+(k-1)*fs:k*fs).*base); 
			endif
			endfor
	else
%Detecci�n polares y Manchester
	for k=1:length(serial);
        det1(k)=mean(yr(1+(k-1)*fs:k*fs).*base);  
	endfor
endif

      for k=1:length(serial)
                if det1(k)>0
                    recibidos(k)=1;
                else
                    recibidos(k)=0;
                end
end
r=[];
for i=1:100
        switch recibidos(i)
            case 0
                r=[r  ceros];
            case 1
                r=[r  unos];
           
        end
                
end

figure(1)
subplot(2,1,1)
plot(t,y1)	
legend ('Secuencia de Bits');
xlabel('Segundos');
axis([0 100 -3 3]);

subplot(2,1,2)
plot(t1,y)	
legend ('Senal Codificada');
xlabel('Segundos');
axis([0 100 -3 3]);

figure(2)
plot(f1,dep1)	
legend ('DEP Senal Codificada');
xlabel('Frecuencia en Hz');

figure(3)
subplot(2,1,1)
plot(t,y1)	
legend ('Secuencia de Bits');
xlabel('Segundos');
axis([0 100 -3 3]);

subplot(2,1,2) 

plot(t1,r)	
legend ('senal recuperada'); 
xlabel('Frecuencia en Hz');
axis([0 100 -3 3]);

if ruido==1
dep2=fftshift((abs(fft(yr))).^2)/lse;
figure (4)
subplot(2,1,1)
plot(t1,yr);title('Ruido+ senal (t)')
subplot(2,1,2)
plot(t1,y)	
legend ('Senal Codificada');
xlabel('Segundos');
axis([0 100 -3 3]);
figure (5)
plot(f1,dep2) ;title('DEP Ruido+Senal')
endif