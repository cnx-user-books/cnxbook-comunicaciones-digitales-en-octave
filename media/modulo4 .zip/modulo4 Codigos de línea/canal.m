function [yr] = canal(y,fs,p)
%%%%%%%%%%%%%%%%%%%%%%ruidooooo%%%%%%%%%%%%%%%%%%%%
senal=y; %se�al DSSSbb,pb o PRK
P=p;%P es la potencia de ruido en W introducida por el usuario
yr=senal + sqrt(P)*randn(1,length(senal));%yruido es la se�al +ruido
            nita=2*P/fs 
            S=mean (y.*y);%potencia de la se�al
            tb=1;%t bit
            E=S*tb%energia de la se�al
            En= E/nita;%da la relacion E/n 
            Endb=10*log(En);% E/n en dB
			end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%