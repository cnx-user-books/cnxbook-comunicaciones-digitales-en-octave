%#programa 5 Codigos de Linea
%Autor: Antonella Paredes
clc% limpiar pantalla  
clear all 
close all
disp("       Programa 5:  Introducci�n C�digos de l�nea                           \n "); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("%    Este programa es una simulaci�n donde se            %"); 
disp("%  genera una secuencia de bits aleatoria (100 bits)     %"); 
disp("%  Se  reliza la codificaci�n utilizando  NRZp y RZp     %"); 
disp("%  El tiempo de bit de fija en 1 segundo                 %"); 
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	

%------------------Introducci�n------------------------------------
disp("%-------------------------------------------------------%");
disp("%    La Codificaci�n de l�nea surge de la necesidad de  %");
disp("%  representar una se�al en formato digital a trav�s    %");
disp("%  de diversos medios de transmisi�n.                   %");
disp("%                                                       %");
disp("%    Se asignan formas de onda arbitrarias a cada bit   %");
disp("%  o s�mbolo que representa la se�al.                   %");
disp("%-------------------------------------------------------%");	
pause(10)

%--------------- Preguntas Iniciales-----------------------------------
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%  Antes de realizar la simulaci�n usted debe responder     %");
disp("%          las siguientes preguntas de selecci�n:           %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	
pause(5)
disp("\n "); 
disp("%-----------------------------------------------------------%");
disp("%  1.Al implementar la codificaci�n de l�nea en una se�al,  %");
disp("%   �qu� par�metros de la misma se ven afectados?:          %");
disp("%    (a)La Potencia de Transmisi�n                          %"); 
disp("%    (b)El Nivel DC                                         %");  
disp("%    (c)El Ancho de Banda requerido por el canal            %");  
disp("%    (d)Todas las anteriores                                %");  
disp("%-----------------------------------------------------------%");	
input(" ");
r1=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(3)
tr=0;
if r1=='d'
	tr=tr+1;
else
	disp("Respuesta Incorrecta. Al realizar codificaci�n de l�nea se generan cambios"); 
	disp(" en  par�metros  de la se�al como lo son la Potencia de Transmisi�n,"); 
	disp("el Ancho de Banda requerido por el canal, nivel DC, entre otros. ");
	pause(4)
endif

disp("\n "); 
disp("%-----------------------------------------------------------------------%");
disp("%  2.El tiempo de bit (tb) se define como:                              %");
disp("%    (a)El tiempo para transmitir la se�al codificada                   %"); 
disp("%    (b)El tiempo para representar la se�al codificada                  %"); 
disp("%    (c)El tiempo para representar y transmitir un bit en el sistema    %"); 
disp("%-----------------------------------------------------------------------%");	
r2=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(3)
if r2=='c'
	tr=tr+1;
else
	disp("Respuesta Incorrecta. El tiempo de bit es el tiempo para representar y tranmitir  un bit en el sistema  ");
	pause(2)
endif
 
disp("\n "); 
disp("%-----------------------------------------------------------------------%");
disp("%  3. Los C�digos de l�nea NRZ polar y unipolar  se caracterizan por:   %");
disp("%    (a)Mantener constante el valor de la se�al de l�nea durante el tb  %"); 
disp("%    (b)Cambiar el valor de la se�al de l�nea durante el tb             %"); 
disp("%    (c)Asignar valores de +v y -v a los bits                           %"); 
disp("%-----------------------------------------------------------------------%");	
r3=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(3)
if r3=='a'
	tr=tr+1;
else 
	disp("Respuesta Incorrecta. Los c�digos NRZp  y NRZu se caracterizan por mantener constante el valor de la se�al de l�nea durante el tb  ");
	pause(2)
endif
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  Generaci�n de bits    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(" A continuaci�n se presenta la secuencia de bits generada: ");
pause(4)
b=randint(1,100)%Genera un vector 1x100 con bit aleatorios con igual probabilidad de ocurrencia
%para relizar una gr�fica con la secuencia de bit 
%se le asigna 10 muetsras a cada bit. 
fm=5;%frecuencia de muestreo
unos=ones(1,fm);
ceros=zeros(1,fm);

y=[];
for i=1:100
        switch b(i)
            case 0
                y=[y  ceros];
            case 1
                y=[y  unos];
           
        end
                
end
l=length(y);
t=(0:(l-1))/fm;%vector de tiempo 
serial=b;

%-------------------------------------------------
%tipo codificaci�n  en este ejemplo sera  'NRZ' y 'RZ'
fs=100;%puntos
uNRZ=ones(1,fs);%base no retorno a cero
uRZ=[ones(1,fs/2) zeros(1,fs/2)];%base retorno a cero


%codificaci�n de la se�al
% codificaci�n con NRZ
ynrz=[];
for i=1:length(serial)
    switch serial(i)
        case 1
            ynrz=[ynrz  uNRZ];
        case 0
            ynrz=[ynrz  -uNRZ];
    end
end

% ynrz se�al codificada NRZ
 
lse=length(ynrz);
t1=(0:(lse-1))/fs;


% codificaci�n con RZ
yrz=[];
for i=1:length(serial)
    switch serial(i)
        case 1
            yrz=[yrz  uRZ];
        case 0
            yrz=[yrz  -uRZ];
    end
end 
 % ynrz se�al codificada RZ
 disp("%  El tiempo de bit es 1 segundo %"); 



%-----------------Gr�ficas de las se�ales codificadas en tiempo---------------------
figure(1)
subplot(3,1,1)
plot(t,y)	
axis([0 100 -2 2]);
legend ('Secuencia de bits');
subplot(3,1,2)
plot(t1,ynrz)	
axis([0 100 -2 2]);
legend ('Senal Codificada NRZp');
subplot(3,1,3)
plot(t1,yrz)	
axis([0 100 -2 2]);
legend ('Senal Codificada RZp');
xlabel('t (s)');
 
%--------------DEP de las se�ales codificadas------------------------
dep1=fftshift((abs(fft(ynrz))).^2)/lse;  %DEP de NRZ
dep2=fftshift((abs(fft(yrz))).^2)/lse;  %DEP de RZ
f1=linspace(-fs/2,fs/2,lse);

%---------------Gr�ficas de las DEP----------------------------------
figure(2)
plot(f1,dep1)	
legend ('DEP Senal Codificada NRZp');
xlabel('Frecuencia en Hz');

figure(3)
plot(f1,dep2)	
legend ('DEP Senal Codificada RZp');
xlabel('Frecuencia en Hz');
%--------------------Preguntas de autoevaluaci�n--------------------------------
pause(10)

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
disp("%                     Autoevaluaci�n          	                        %"); 
disp("%                                                                       %");  
disp("% A partir de los resultados obtenidos en las gr�ficas se le realizar�  %");
disp("% una  pregunta para comprobar su comprensi�n sobre los                 %");
disp("% resultados arrojados en la simulaci�n.                                %"); 
disp("%                                                                       %");  
disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");	

disp("\n "); 
disp("%-----------------------------------------------------------------------%");
disp("%  4. El Ancho de banda de la se�al codificada es :                     %");
disp("%    (a)Mayor cuando hay  m�s transiciones por  tiempo de bit           %"); 
disp("%    (b)Mayor cuando hay menos transiciones por tiempo de bit           %"); 
disp("%    (c)Independiente del n�mero de transiciones por tiempo de bit      %"); 
disp("%-----------------------------------------------------------------------%");	
r4=input("respuesta:",'%c');%el usuario introduce su respuesta
pause(3)
if r4=='a'
	tr=tr+1;
else 
	disp("Respuesta Incorrecta. El ancho de banda de la se�al es mayor al haber mas transiciones por unidad de tiempo.  ");
	pause(2)
endif
 
if tr>=3 
	disp("  Su total de respuesta correctas fue superior a 3, usted puede ejecutar el m�dulo de C�digos de L�nea");
else
	disp(" Su total de respuesta correctas fue inferior a 3.  Se recomienda repasar los contenidos de este m�dulo");
	endif
